import React, { useState } from 'react';
import { 
  X, Search, Plus, Trash2, Edit, Save, ShoppingBag, Phone, Share2, 
  ClipboardList, TrendingUp, Check, AlertCircle, Settings, LogOut, 
  Lock, MapPin, AlertTriangle, Users 
} from 'lucide-react';
import { Product, Order } from '../types';

interface SupportStaff {
  id: string;
  name: string;
  icon: string;
  phone: string;
  role: string;
}

interface SocialLinks {
  instagram: string;
  facebook: string;
  whatsapp: string;
  tiktok: string;
  announcement: string;
  storeAddress: string;
  storePhone: string;
  heroBanner?: string;
}

interface AdminPanelProps {
  products: Product[];
  onUpdateProducts: (products: Product[]) => void;
  categories: any[];
  onUpdateCategories: (categories: any[]) => void;
  orders: Order[];
  onUpdateOrders: (orders: Order[]) => void;
  supportStaff: SupportStaff[];
  onUpdateSupportStaff: (staff: SupportStaff[]) => void;
  socialLinks: SocialLinks;
  onUpdateSocialLinks: (links: SocialLinks) => void;
  onClose: () => void;
}

export function AdminPanel({
  products,
  onUpdateProducts,
  categories,
  onUpdateCategories,
  orders,
  onUpdateOrders,
  supportStaff,
  onUpdateSupportStaff,
  socialLinks,
  onUpdateSocialLinks,
  onClose
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'stats' | 'products' | 'orders' | 'categories' | 'support' | 'settings'>('stats');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Product state forms
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  const [prodForm, setProdForm] = useState({
    name: '',
    price: 0,
    originalPrice: 0,
    discountText: '',
    statusText: 'In Stock',
    category: '',
    description: '',
    imageUrl: '',
    sizes: 'S,M,L,XL',
    colors: 'Black,White',
    isNewArrival: false,
    isBestSeller: false
  });

  // Category forms
  const [newCatName, setNewCatName] = useState('');
  const [newCatImage, setNewCatImage] = useState('');

  // Support staffs forms
  const [staffForm, setStaffForm] = useState<SupportStaff[]>(supportStaff);

  // Stats calculation
  const totalSales = orders
    .filter(o => o.status === 'Delivered' || o.status === 'Approved' || o.status === 'Shipped')
    .reduce((sum, o) => sum + o.totalAmount, 0);
  const pendingOrdersCount = orders.filter(o => o.status === 'Pending').length;
  const outOfStockCount = products.filter(p => p.statusText === 'Out Of Stock').length;

  const handleEditProductClick = (product: Product) => {
    setEditingProduct(product);
    setProdForm({
      name: product.name,
      price: product.price,
      originalPrice: product.originalPrice || 0,
      discountText: product.discountText || '',
      statusText: product.statusText || 'In Stock',
      category: product.category,
      description: product.description,
      imageUrl: product.images[0] || '',
      sizes: product.sizes ? product.sizes.join(',') : '',
      colors: product.colors ? product.colors.join(',') : '',
      isNewArrival: !product.isNewArrival,
      isBestSeller: !product.isBestSeller,
    });
    // Set boolean parameters explicitly to prevent inverted toggles
    setProdForm(prev => ({
      ...prev,
      isNewArrival: !!product.isNewArrival,
      isBestSeller: !!product.isBestSeller
    }));
    setIsProductModalOpen(true);
  };

  const handleAddNewProductClick = () => {
    setEditingProduct(null);
    setProdForm({
      name: '',
      price: 0,
      originalPrice: 0,
      discountText: '',
      statusText: 'In Stock',
      category: categories[0]?.name || 'Formal Wear',
      description: '',
      imageUrl: '',
      sizes: 'S,M,L,XL',
      colors: 'Black,White',
      isNewArrival: true,
      isBestSeller: false
    });
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodForm.name || !prodForm.category || !prodForm.imageUrl) return;

    const sizeArray = prodForm.sizes ? prodForm.sizes.split(',').map(s => s.trim()).filter(Boolean) : [];
    const colorArray = prodForm.colors ? prodForm.colors.split(',').map(c => c.trim()).filter(Boolean) : [];

    const updatedProduct: Product = {
      id: editingProduct ? editingProduct.id : Date.now().toString(),
      name: prodForm.name,
      price: Number(prodForm.price),
      originalPrice: prodForm.originalPrice ? Number(prodForm.originalPrice) : undefined,
      discountText: prodForm.discountText || undefined,
      statusText: prodForm.statusText,
      category: prodForm.category as any,
      description: prodForm.description,
      images: [prodForm.imageUrl],
      sizes: sizeArray,
      colors: colorArray,
      isNewArrival: prodForm.isNewArrival,
      isBestSeller: prodForm.isBestSeller,
      reviews: editingProduct?.reviews || []
    };

    if (editingProduct) {
      // Edit
      const newList = products.map(p => p.id === editingProduct.id ? updatedProduct : p);
      onUpdateProducts(newList);
    } else {
      // Add
      onUpdateProducts([updatedProduct, ...products]);
    }

    setIsProductModalOpen(false);
    setEditingProduct(null);
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      onUpdateProducts(products.filter(p => p.id !== id));
    }
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    const updated = orders.map(o => {
      if (o.id === orderId) {
        return { ...o, status };
      }
      return o;
    });
    onUpdateOrders(updated);
  };

  const handleDeleteOrder = (orderId: string) => {
    if (window.confirm('Delete this order record permanently?')) {
      onUpdateOrders(orders.filter(o => o.id !== orderId));
    }
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName || !newCatImage) return;

    const newCat = {
      id: Date.now().toString(),
      name: newCatName,
      image: newCatImage
    };

    onUpdateCategories([...categories, newCat]);
    setNewCatName('');
    setNewCatImage('');
  };

  const handleDeleteCategory = (id: string) => {
    if (window.confirm('Are you sure you want to delete this category? (Products assigned to it will remain unaffected but categories will adjust.)')) {
      onUpdateCategories(categories.filter(c => c.id !== id));
    }
  };

  const handleSaveStaffSettings = (id: string, updatedFields: Partial<SupportStaff>) => {
    const updated = staffForm.map(s => {
      if (s.id === id) {
        return { ...s, ...updatedFields };
      }
      return s;
    });
    setStaffForm(updated);
    onUpdateSupportStaff(updated);
  };

  const handleSaveSocials = (field: keyof SocialLinks, value: string) => {
    const updated = { ...socialLinks, [field]: value };
    onUpdateSocialLinks(updated);
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-[#050505] min-h-screen text-gray-200 font-sans border-t border-gray-800">
      {/* Admin header */}
      <div className="bg-[#0c0c0c] border-b border-gray-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 bg-gold rounded-full animate-pulse shadow-[0_0_8px_rgba(212,175,55,0.8)]"></span>
              <span className="text-[11px] text-gold font-bold uppercase tracking-[0.25em] font-mono">Dapper Outfits Studio</span>
            </div>
            <h1 className="text-2xl font-black text-white uppercase tracking-wider mt-1">Orvex Control Center</h1>
          </div>
          <button 
            onClick={onClose}
            className="flex items-center gap-2 border border-gray-800 hover:border-gold py-2 px-5 rounded-lg text-sm text-gray-400 hover:text-white transition-all bg-black"
          >
            <LogOut size={16} /> Exit Panel
          </button>
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap border-b border-gray-800 gap-2 mb-8 pb-3">
          {[
            { id: 'stats', label: 'Dashboard Stats', icon: <TrendingUp size={16} /> },
            { id: 'products', label: 'Products Master', icon: <ShoppingBag size={16} /> },
            { id: 'orders', label: 'Customer Orders', icon: <ClipboardList size={16} /> },
            { id: 'categories', label: 'Categories Layout', icon: <Share2 size={16} /> },
            { id: 'support', label: 'Support Representatives', icon: <Users size={16} /> },
            { id: 'settings', label: 'Global Configurations', icon: <Settings size={16} /> },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 py-2 px-5 font-bold text-xs uppercase tracking-wider rounded-lg transition-all ${
                activeTab === tab.id 
                  ? 'bg-gold text-black border border-gold' 
                  : 'text-gray-400 hover:text-white bg-[#111] hover:bg-[#151515] border border-gray-800'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* --- STATS DASHBOARD --- */}
        {activeTab === 'stats' && (
          <div className="space-y-8 animate-fade-in">
            {/* Bento Grid Analytics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-[#111] border border-gray-800 rounded-xl p-6 relative overflow-hidden flex flex-col justify-between h-36">
                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 blur-2xl rounded-full"></div>
                <div>
                  <span className="text-gray-500 text-[10px] uppercase tracking-wider font-mono">Gross Sales Revenue</span>
                  <p className="text-2xl font-black text-white mt-1">Tk {totalSales}</p>
                </div>
                <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                  • Approved & Delivered
                </div>
              </div>

              <div className="bg-[#111] border border-gray-800 rounded-xl p-6 relative overflow-hidden flex flex-col justify-between h-36">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 blur-2xl rounded-full"></div>
                <div>
                  <span className="text-gray-500 text-[10px] uppercase tracking-wider font-mono">Pending Desk Orders</span>
                  <p className="text-2xl font-black text-white mt-1">{pendingOrdersCount} Order{pendingOrdersCount !== 1 ? 's' : ''}</p>
                </div>
                <div className="text-[11px] text-gold font-bold flex items-center gap-1">
                  • Requires processing
                </div>
              </div>

              <div className="bg-[#111] border border-gray-800 rounded-xl p-6 relative overflow-hidden flex flex-col justify-between h-36">
                <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/5 blur-2xl rounded-full"></div>
                <div>
                  <span className="text-gray-500 text-[10px] uppercase tracking-wider font-mono">Total Store Products</span>
                  <p className="text-2xl font-black text-white mt-1">{products.length} Items</p>
                </div>
                <div className="text-[11px] text-gray-400 flex items-center gap-1">
                  • Distributed in {categories.length} segments
                </div>
              </div>

              <div className="bg-[#111] border border-gray-800 rounded-xl p-6 relative overflow-hidden flex flex-col justify-between h-36">
                <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/5 blur-2xl rounded-full"></div>
                <div>
                  <span className="text-gray-500 text-[10px] uppercase tracking-wider font-mono">Inventory Stock Health</span>
                  <p className="text-2xl font-black text-orange-400 mt-1">{outOfStockCount} Out of Stock</p>
                </div>
                <div className="text-[11px] text-orange-400 font-bold flex items-center gap-1">
                  • Review item settings below
                </div>
              </div>
            </div>

            {/* Quick Actions and Logs */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Box 1 */}
              <div className="lg:col-span-2 bg-[#111] border border-gray-800 p-6 rounded-xl">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white">Recent Customer Submissions</h3>
                  <button onClick={() => setActiveTab('orders')} className="text-xs text-gold hover:underline">View All &rarr;</button>
                </div>
                {orders.length === 0 ? (
                  <div className="text-center py-10 border border-dashed border-gray-800 rounded-lg">
                    <ClipboardList className="mx-auto text-gray-600 mb-2" size={32} />
                    <p className="text-xs text-gray-500">No client orders received yet. Active checkouts will display here immediately.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.slice(0, 4).map(order => (
                      <div key={order.id} className="bg-black border border-gray-800 p-4 rounded-lg flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-white uppercase">{order.customerName}</span>
                            <span className="text-[10px] text-gray-500 font-mono">#{order.id}</span>
                          </div>
                          <p className="text-[11px] text-gray-400 mt-1">{order.items.length} items • Tk {order.totalAmount}</p>
                          <p className="text-[10px] text-gray-500 mt-0.5">{order.date}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded ${
                            order.status === 'Pending' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' :
                            order.status === 'Approved' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                            order.status === 'Shipped' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' :
                            order.status === 'Delivered' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                            'bg-red-500/10 text-red-500 border border-red-500/20'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Box 2 */}
              <div className="bg-[#111] border border-gray-800 p-6 rounded-xl flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white mb-4">Admin Shortcuts</h3>
                  <p className="text-xs text-gray-400 leading-relaxed font-light mb-6">
                    Easily maintain your digital storefront catalog. Click buttons below to launch wizards directly.
                  </p>
                  <div className="space-y-3">
                    <button 
                      onClick={handleAddNewProductClick}
                      className="w-full bg-gold hover:bg-opacity-90 text-black py-2.5 rounded font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-sm"
                    >
                      <Plus size={14} /> Add New Design
                    </button>
                    <button 
                      onClick={() => setActiveTab('settings')}
                      className="w-full bg-[#1c1c1c] hover:bg-[#252525] border border-gray-800 py-2.5 rounded font-bold text-xs uppercase tracking-wider text-white flex items-center justify-center gap-2 transition-all"
                    >
                      <Settings size={14} /> Shop Alert Notice
                    </button>
                  </div>
                </div>
                <div className="mt-8 pt-4 border-t border-gray-800 text-[11px] text-gray-500 leading-relaxed">
                  Authentication email is registered as <span className="text-gold font-mono font-bold">dapper.outfits12@gmail.com</span> on this secure container node.
                </div>
              </div>
            </div>
          </div>
        )}


        {/* --- PRODUCTS MASTER VIEW (CRUD) --- */}
        {activeTab === 'products' && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="relative w-full sm:w-80">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">
                  <Search size={16} />
                </span>
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-black border border-gray-800 hover:border-gray-700 rounded-lg pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <button 
                onClick={handleAddNewProductClick}
                className="bg-gold hover:bg-opacity-90 text-black py-2 px-5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all shadow-md shrink-0"
              >
                <Plus size={16} /> New Product
              </button>
            </div>

            <div className="bg-[#111] border border-gray-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-black border-b border-gray-800 text-gray-400 font-bold uppercase tracking-wider">
                      <th className="py-4 px-6">Product Details</th>
                      <th className="py-4 px-6">Category</th>
                      <th className="py-4 px-6">Price Details</th>
                      <th className="py-4 px-6">Availability</th>
                      <th className="py-4 px-6">Specs</th>
                      <th className="py-4 px-6 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800 text-gray-300">
                    {filteredProducts.map(product => (
                      <tr key={product.id} className="hover:bg-black/40 transition-colors">
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-4">
                            <img 
                              src={product.images[0]} 
                              alt={product.name} 
                              className="w-12 h-16 object-cover rounded border border-gray-850 bg-gray-900"
                            />
                            <div>
                              <div className="font-bold text-white text-sm hover:text-gold transition-colors">{product.name}</div>
                              <span className="text-[10px] text-gray-500 font-mono mt-0.5 block">ID: {product.id}</span>
                              <div className="flex gap-1 mt-1.5">
                                {product.isNewArrival && <span className="bg-[#ed3237] text-white text-[9px] font-black uppercase px-2.5 py-0.5 rounded-sm">New</span>}
                                {product.isBestSeller && <span className="bg-gold text-black text-[9px] font-black uppercase px-2.5 py-0.5 rounded-sm">Seller</span>}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-6 text-gray-400 font-medium">{product.category}</td>
                        <td className="py-4 px-6 font-mono font-semibold">
                          <div>Tk {product.price}</div>
                          {product.originalPrice && (
                            <div className="text-gray-500 line-through text-[10px] mt-0.5">Tk {product.originalPrice}</div>
                          )}
                          {product.discountText && (
                            <div className="text-gold text-[10px] mt-0.5">{product.discountText}</div>
                          )}
                        </td>
                        <td className="py-4 px-6">
                          <span className={`inline-flex items-center justify-center font-bold px-2 py-0.5 rounded-sm text-[10px] font-mono ${
                            product.statusText !== 'Out Of Stock' 
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25' 
                              : 'bg-red-500/10 text-red-500 border border-red-500/25'
                          }`}>
                            {product.statusText || 'In Stock'}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-[11px] text-gray-400 font-light max-w-xs truncate">
                          <div><strong className="text-[10px] text-gray-500">Sizes:</strong> {product.sizes?.join(', ') || 'None'}</div>
                          <div className="mt-1"><strong className="text-[10px] text-gray-500">Colors:</strong> {product.colors?.join(', ') || 'None'}</div>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex justify-center items-center gap-3">
                            <button 
                              onClick={() => handleEditProductClick(product)}
                              className="text-gray-400 hover:text-gold p-1.5 bg-black border border-gray-800 rounded hover:border-gold transition-all"
                              title="Edit specifications"
                            >
                              <Edit size={14} />
                            </button>
                            <button 
                              onClick={() => handleDeleteProduct(product.id)}
                              className="text-gray-400 hover:text-red-500 p-1.5 bg-black border border-gray-800 rounded hover:border-red-500 transition-all"
                              title="Delete design"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filteredProducts.length === 0 && (
                <div className="text-center py-16 text-gray-500">
                  No matching catalogs found under your query "{searchQuery}".
                </div>
              )}
            </div>
          </div>
        )}


        {/* --- CUSTOMER ORDERS TRACKER --- */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-[#111] border border-gray-800 p-6 rounded-xl">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white mb-2">Order Records & Cash-On-Delivery Control</h3>
              <p className="text-xs text-gray-400 font-light leading-relaxed">
                Log and process order states manually. Updating order states modifies totals metrics.
              </p>
            </div>

            {orders.length === 0 ? (
              <div className="text-center py-20 border border-dashed border-gray-800 bg-[#111] rounded-xl">
                <ClipboardList className="mx-auto text-gray-600 mb-3" size={48} />
                <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-1">No Orders Placed Yet</h4>
                <p className="text-xs text-gray-550 max-w-sm mx-auto leading-relaxed">
                  When visitors add items to cart and submit their delivery names, addresses, and Bangladesh contact numbers, the entries show up here immediately with beep signals.
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {orders.map(order => (
                  <div key={order.id} className="bg-[#111] p-6 rounded-xl border border-gray-800 flex flex-col lg:flex-row justify-between gap-6 transition-all duration-350 hover:border-gold">
                    <div className="space-y-4 flex-1">
                      {/* Customer Details */}
                      <div>
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="font-extrabold text-sm text-white uppercase tracking-wide">{order.customerName}</span>
                          <span className="font-mono text-[10px] text-gray-500 bg-black/60 px-2 py-0.5 rounded border border-gray-850">ID: #{order.id}</span>
                          <span className="font-mono text-[10px] text-gray-400">{order.date}</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 mt-3 font-mono text-[11px] text-gray-400">
                          <div className="flex items-start gap-2">
                            <strong className="text-[10px] text-gray-500 uppercase shrink-0 mt-0.5">Phone:</strong> 
                            <span className="text-white font-bold">{order.customerPhone}</span>
                          </div>
                          {order.customerAltPhone && (
                            <div className="flex items-start gap-2">
                              <strong className="text-[10px] text-gray-500 uppercase shrink-0 mt-0.5">Alt Phone:</strong> 
                              <span className="text-gray-300">{order.customerAltPhone}</span>
                            </div>
                          )}
                          <div className="flex items-start gap-2 sm:col-span-2">
                            <strong className="text-[10px] text-gray-500 uppercase shrink-0 mt-0.5">Address:</strong> 
                            <span className="text-white">{order.customerAddress}</span>
                          </div>
                          {(order.customerDistrict || order.customerDivision) && (
                            <div className="flex items-start gap-2">
                              <strong className="text-[10px] text-gray-500 uppercase shrink-0 mt-0.5">Region:</strong> 
                              <span className="text-gray-300">
                                {order.customerDistrict && `${order.customerDistrict}`}
                                {order.customerDivision && `, ${order.customerDivision} Division`}
                              </span>
                            </div>
                          )}
                          {order.shippingCost !== undefined && (
                            <div className="flex items-start gap-2">
                              <strong className="text-[10px] text-gray-500 uppercase shrink-0 mt-0.5">Shipping:</strong> 
                              <span className="text-gold font-bold">Tk {order.shippingCost}</span>
                            </div>
                          )}
                          {order.deliveryNotes && (
                            <div className="flex items-start gap-2 sm:col-span-2 bg-[#1b1212] border border-red-950/40 p-2 rounded text-[11px] text-red-300">
                              <strong className="text-[10px] text-red-400 uppercase shrink-0 mt-0.5">Instructions:</strong> 
                              <span>{order.deliveryNotes}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Items Details */}
                      <div className="border-t border-gray-850 pt-3.5 space-y-3">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-gold block">Ordered Items:</span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex gap-3 bg-black/50 p-2.5 rounded border border-gray-850 items-center">
                              <img src={item.image} alt={item.productName} className="w-10 h-14 object-cover rounded border border-gray-800" />
                              <div className="text-xs">
                                <div className="font-bold text-white line-clamp-1">{item.productName}</div>
                                <div className="text-gray-500 mt-1">Qt: <strong className="text-white">{item.quantity}</strong> • Tk {item.price}</div>
                                { (item.size || item.color) && (
                                  <div className="text-[10px] text-gray-400 font-mono uppercase mt-0.5">{item.size && `Size: ${item.size}`} {item.color && `Color: ${item.color}`}</div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="lg:border-l border-gray-800 lg:pl-6 shrink-0 flex flex-col justify-between items-start lg:items-end gap-4 min-w-[200px]">
                      {/* Total and current status */}
                      <div className="text-left lg:text-right">
                        <span className="text-gray-500 text-[10px] uppercase font-mono tracking-wider block">Total Cart Settlement</span>
                        <div className="text-xl font-mono font-black text-white mt-1">Tk {order.totalAmount}</div>
                        <div className="mt-1.5 flex items-center gap-2">
                          <span className="text-[10px] text-gray-500">Status:</span>
                          <span className={`text-[10px] font-mono font-black uppercase px-2.5 py-0.5 rounded ${
                            order.status === 'Pending' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20 animate-pulse' :
                            order.status === 'Approved' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                            order.status === 'Shipped' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' :
                            order.status === 'Delivered' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                            'bg-red-500/10 text-red-500 border border-red-500/20'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                      </div>

                      {/* State modifications */}
                      <div className="w-full flex flex-col gap-2 shrink-0">
                        <div className="grid grid-cols-2 gap-1.5">
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'Approved')}
                            className="bg-blue-600/15 hover:bg-blue-600/30 text-blue-400 py-1.5 px-2.5 rounded font-bold text-[10px] uppercase tracking-wider transition-all border border-blue-500/20 hover:border-blue-400"
                          >
                            Approve
                          </button>
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'Shipped')}
                            className="bg-purple-600/15 hover:bg-purple-600/30 text-purple-400 py-1.5 px-2.5 rounded font-bold text-[10px] uppercase tracking-wider transition-all border border-purple-500/20 hover:border-purple-400"
                          >
                            Ship
                          </button>
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'Delivered')}
                            className="bg-emerald-600/15 hover:bg-emerald-600/30 text-emerald-400 py-1.5 px-2.5 rounded font-bold text-[10px] uppercase tracking-wider transition-all border border-emerald-500/20 hover:border-emerald-400"
                          >
                            Deliver
                          </button>
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'Cancelled')}
                            className="bg-red-600/15 hover:bg-red-600/30 text-red-400 py-1.5 px-2.5 rounded font-bold text-[10px] uppercase tracking-wider transition-all border border-red-500/20 hover:border-red-400"
                          >
                            Cancel
                          </button>
                        </div>
                        <button 
                          onClick={() => handleDeleteOrder(order.id)}
                          className="text-[10px] font-bold uppercase py-1.5 px-2 bg-black border border-dashed border-gray-800 hover:border-red-500 hover:text-red-500 transition-colors rounded text-center block w-full mt-1.5"
                        >
                          Delete Record
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}


        {/* --- CATEGORIES LAYOUT MANAGEMENT --- */}
        {activeTab === 'categories' && (
          <div className="space-y-8 animate-fade-in">
            {/* Form category add */}
            <form onSubmit={handleAddCategory} className="bg-[#111] border border-gray-800 p-6 rounded-xl max-w-xl">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white mb-4">Add Custom Category Segment</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-400 text-xs mb-1 font-mono uppercase">Category Name</label>
                  <input
                    type="text"
                    value={newCatName}
                    onChange={e => setNewCatName(e.target.value)}
                    required
                    placeholder="e.g., Casual Punjabi"
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold transition-colors text-white"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-xs mb-1 font-mono uppercase">Category Banner Image URL</label>
                  <input
                    type="text"
                    value={newCatImage}
                    onChange={e => setNewCatImage(e.target.value)}
                    required
                    placeholder="Unsplash pattern image URL"
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white font-mono transition-colors"
                  />
                </div>
                <button 
                  type="submit" 
                  className="bg-gold hover:bg-opacity-95 text-black py-2.5 px-6 rounded font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all"
                >
                  <Plus size={14} /> Add Category
                </button>
              </div>
            </form>

            {/* List */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {categories.map(category => (
                <div key={category.id} className="relative group bg-[#111] border border-gray-800 rounded-lg overflow-hidden">
                  <div className="aspect-square bg-gray-900 relative">
                    <img src={category.image} alt={category.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center p-3 text-center">
                      <span className="font-bold text-white text-xs uppercase tracking-wide">{category.name}</span>
                    </div>
                  </div>
                  <div className="p-2.5 bg-black border-t border-gray-800 flex justify-end">
                    <button 
                      onClick={() => handleDeleteCategory(category.id)}
                      className="text-gray-500 hover:text-red-500 font-mono text-[9px] uppercase hover:underline transition-colors flex items-center gap-1 font-bold"
                    >
                      <Trash2 size={11} /> Delete Layout
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}


        {/* --- SUPPORT REPRESENTATIVES INFO (AS ASKED FOR SECURE DIRECT ACCESS) --- */}
        {activeTab === 'support' && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-[#111] border border-gray-800 p-6 rounded-xl">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white mb-2">Support Representative Channels</h3>
              <p className="text-xs text-gray-400 font-light leading-relaxed">
                Configure your Bangladesh WhatsApp care team. Any change made below updates the main Support Widget and Contact page immediately.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {staffForm.map(staff => (
                <div key={staff.id} className="bg-[#111] p-6 rounded-xl border border-gray-800 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gold/10 border border-gold/25 rounded-full flex items-center justify-center text-gold font-bold text-xs uppercase font-mono">
                      {staff.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white">{staff.name}</h4>
                      <p className="text-[10px] text-gray-500 uppercase tracking-wider">{staff.role}</p>
                    </div>
                  </div>

                  <div className="space-y-3 pt-3 border-t border-gray-850">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase font-mono mb-1">Representative Name</label>
                      <input 
                        type="text"
                        value={staff.name}
                        onChange={e => handleSaveStaffSettings(staff.id, { name: e.target.value, icon: e.target.value.split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase() })}
                        className="w-full bg-black border border-gray-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase font-mono mb-1">WhatsApp Number (e.g., 01xxxxxxxxx)</label>
                      <input 
                        type="text"
                        value={staff.phone}
                        onChange={e => handleSaveStaffSettings(staff.id, { phone: e.target.value })}
                        className="w-full bg-black border border-gray-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase font-mono mb-1">Role/Department Name</label>
                      <input 
                        type="text"
                        value={staff.role}
                        onChange={e => handleSaveStaffSettings(staff.id, { role: e.target.value })}
                        className="w-full bg-black border border-gray-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}


        {/* --- GLOBAL CONFIGURATIONS --- */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-3xl animate-fade-in">
            <div className="bg-[#111] border border-gray-800 p-6 rounded-xl space-y-6">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white border-b border-gray-800 pb-2">Website Layout Constants</h3>

              {/* Announcement notice */}
              <div className="space-y-2">
                <label className="block text-xs uppercase font-mono text-gray-400 font-bold">Top Bar / Header Announcement Alert text</label>
                <textarea
                  value={socialLinks.announcement}
                  onChange={e => handleSaveSocials('announcement', e.target.value)}
                  rows={2}
                  className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white transition-colors leading-relaxed"
                />
                <span className="text-[10.5px] text-gray-500 block leading-normal italic">
                  Displays at the top of the webpage. Keep under 110 characters for perfect line containment on mobile grids.
                </span>
              </div>

              {/* Store GPS coordinates / Branch address details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-mono text-gray-400 font-bold">Branch Physical Address</label>
                  <input
                    type="text"
                    value={socialLinks.storeAddress}
                    onChange={e => handleSaveSocials('storeAddress', e.target.value)}
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white transition-colors"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-mono text-gray-400 font-bold">Support Primary Hot Line</label>
                  <input
                    type="text"
                    value={socialLinks.storePhone}
                    onChange={e => handleSaveSocials('storePhone', e.target.value)}
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white font-mono transition-colors"
                  />
                </div>
              </div>

              {/* Main Hero Banner URL */}
              <div className="space-y-2">
                <label className="block text-xs uppercase font-mono text-gray-400 font-bold">Main Hero Banner Image URL</label>
                <input
                  type="text"
                  value={socialLinks.heroBanner || ''}
                  onChange={e => handleSaveSocials('heroBanner', e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white transition-colors"
                />
                <span className="text-[10.5px] text-gray-500 block leading-normal italic">
                  Displays on the main home page. Use high-resolution images for best quality.
                </span>
              </div>

              {/* Social Channels Links */}
              <h3 className="text-sm font-bold uppercase tracking-wider text-white border-b border-gray-800 pt-4 pb-2">Social Channels Direct Hyperlinks</h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-mono text-gray-400 font-bold">Instagram Hyperlink</label>
                    <input
                      type="text"
                      value={socialLinks.instagram}
                      onChange={e => handleSaveSocials('instagram', e.target.value)}
                      className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white font-mono transition-colors"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-mono text-gray-400 font-bold">Facebook Page Hyperlink</label>
                    <input
                      type="text"
                      value={socialLinks.facebook}
                      onChange={e => handleSaveSocials('facebook', e.target.value)}
                      className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white font-mono transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-mono text-gray-400 font-bold">TikTok Creator Hyperlink</label>
                    <input
                      type="text"
                      value={socialLinks.tiktok}
                      onChange={e => handleSaveSocials('tiktok', e.target.value)}
                      className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white font-mono transition-colors"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-mono text-gray-400 font-bold">WhatsApp Hotline Number (just numbers e.g. 016xxxxx)</label>
                    <input
                      type="text"
                      value={socialLinks.whatsapp}
                      onChange={e => handleSaveSocials('whatsapp', e.target.value)}
                      className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs focus:outline-none focus:border-gold text-white font-mono transition-colors"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* --- ADD/EDIT PRODUCT MODAL WIZARD --- */}
      {isProductModalOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 z-[110] overflow-y-auto">
          <div className="bg-[#0e0e0e] border border-gray-800 rounded-xl max-w-2xl w-full p-6 sm:p-8 relative max-h-[90vh] overflow-y-auto">
            <button 
              onClick={() => setIsProductModalOpen(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
            
            <h3 className="text-lg font-black text-white uppercase tracking-wider mb-6">
              {editingProduct ? 'Modify Product Specifications' : 'Upload Elite Design Catalog'}
            </h3>

            <form onSubmit={handleSaveProduct} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Product Name</label>
                  <input
                    type="text"
                    value={prodForm.name}
                    onChange={e => setProdForm({ ...prodForm, name: e.target.value })}
                    required
                    placeholder="e.g., DEER Punjabi 88"
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Category Segment</label>
                  <select
                    value={prodForm.category}
                    onChange={e => setProdForm({ ...prodForm, category: e.target.value })}
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                  >
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.name}>{cat.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Current Price (Tk)</label>
                  <input
                    type="number"
                    value={prodForm.price}
                    onChange={e => setProdForm({ ...prodForm, price: Number(e.target.value) })}
                    required
                    min={0}
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Original Price (Tk) [optional]</label>
                  <input
                    type="number"
                    value={prodForm.originalPrice}
                    onChange={e => setProdForm({ ...prodForm, originalPrice: Number(e.target.value) })}
                    min={0}
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Discount Text (e.g. OFF 12%)</label>
                  <input
                    type="text"
                    value={prodForm.discountText}
                    onChange={e => setProdForm({ ...prodForm, discountText: e.target.value })}
                    placeholder="e.g. OFF 10%"
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Primary Image URL</label>
                <input
                  type="text"
                  value={prodForm.imageUrl}
                  onChange={e => setProdForm({ ...prodForm, imageUrl: e.target.value })}
                  required
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Available Sizes (comma-separated)</label>
                  <input
                    type="text"
                    value={prodForm.sizes}
                    onChange={e => setProdForm({ ...prodForm, sizes: e.target.value })}
                    placeholder="S,M,L,XL,XXL"
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Available Colors (comma-separated)</label>
                  <input
                    type="text"
                    value={prodForm.colors}
                    onChange={e => setProdForm({ ...prodForm, colors: e.target.value })}
                    placeholder="Black,White,Navy,Gray"
                    className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-mono text-gray-400 mb-2 font-bold">Stock Status</label>
                  <select
                    value={prodForm.statusText}
                    onChange={e => setProdForm({ ...prodForm, statusText: e.target.value })}
                    className="w-full bg-black border border-gray-800 rounded px-2.5 py-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                  >
                    <option value="In Stock">In Stock</option>
                    <option value="Out Of Stock">Out Of Stock</option>
                  </select>
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <input
                    type="checkbox"
                    id="isNewArrival"
                    checked={prodForm.isNewArrival}
                    onChange={e => setProdForm({ ...prodForm, isNewArrival: e.target.checked })}
                    className="accent-gold h-4 w-4 rounded bg-black border-gray-700"
                  />
                  <label htmlFor="isNewArrival" className="text-[11px] font-bold uppercase font-mono text-gray-300 cursor-pointer">New Arrival</label>
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <input
                    type="checkbox"
                    id="isBestSeller"
                    checked={prodForm.isBestSeller}
                    onChange={e => setProdForm({ ...prodForm, isBestSeller: e.target.checked })}
                    className="accent-gold h-4 w-4 rounded bg-black border-gray-700"
                  />
                  <label htmlFor="isBestSeller" className="text-[11px] font-bold uppercase font-mono text-gray-300 cursor-pointer">Best Seller</label>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Product Description</label>
                <textarea
                  value={prodForm.description}
                  onChange={e => setProdForm({ ...prodForm, description: e.target.value })}
                  required
                  rows={4}
                  placeholder="Describe your design premium cuts and aesthetic specs..."
                  className="w-full bg-black border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-gold transition-colors leading-relaxed"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-900">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-5 py-2.5 border border-gray-800 hover:border-gray-700 hover:text-white rounded text-xs font-bold uppercase tracking-wider text-gray-400 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-gold hover:bg-opacity-95 text-black rounded text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all shadow-sm"
                >
                  <Save size={14} /> Commit Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

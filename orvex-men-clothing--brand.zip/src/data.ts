import { Product } from './types';

export const categories = [
  {
    id: '1',
    name: 'Panjabi',
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=800&auto=format&fit=crop', // Temporary placeholder
  },
  {
    id: '2',
    name: 'Shirt',
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '3',
    name: 'Pant',
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '4',
    name: 'Hoodie',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '5',
    name: 'Polo Sweatshirt',
    image: 'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '6',
    name: 'Sweatshirt',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '7',
    name: 'Shoe',
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '8',
    name: 'Jacket',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '9',
    name: 'Combo',
    image: 'https://images.unsplash.com/photo-1479064555552-3ef4979f8908?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: '10',
    name: 'T-shirt',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=800&auto=format&fit=crop',
  }
];

export const products: Product[] = [
  {
    id: '1',
    name: 'DEER Punjabi 28',
    price: 3050,
    originalPrice: 3350,
    discountText: 'OFF 8.96%',
    statusText: 'Out Of Stock',
    viewCount: 163,
    category: 'Formal Wear',
    description: 'A masterpiece of craftsmanship.',
    images: ['https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['White', 'Black'],
    features: ['100% Cotton', 'Embroidery'],
    isNewArrival: true,
    isBestSeller: true
  },
  {
    id: '2',
    name: 'DEER Punjabi 17',
    price: 3050,
    originalPrice: 3350,
    discountText: 'OFF 8.96%',
    statusText: 'Out Of Stock',
    viewCount: 120,
    category: 'Formal Wear',
    description: 'Elegant gray punjabi.',
    images: ['https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['M', 'L', 'XL'],
    colors: ['Gray'],
    features: ['Premium Blend', 'Pockets'],
    isBestSeller: true
  },
  {
    id: '3',
    name: 'DEER Punjabi 34',
    price: 3050,
    originalPrice: 3350,
    discountText: 'OFF 8.96%',
    statusText: 'Out Of Stock',
    viewCount: 163,
    category: 'Formal Wear',
    description: 'White with intricate green pattern.',
    images: ['https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: ['White', 'Green'],
    features: ['Hand Embroidery', 'Slim Fit'],
    isNewArrival: true
  },
  {
    id: '4',
    name: 'DEER Punjabi 16',
    price: 3050,
    originalPrice: 3390,
    discountText: 'OFF 10.03%',
    statusText: 'Out Of Stock',
    viewCount: 200,
    category: 'Formal Wear',
    description: 'Deep blue with contrasting pocket.',
    images: ['https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['M', 'L', 'XL'],
    colors: ['Navy Blue'],
    features: ['Cotton', 'Contrasting Details'],
    isBestSeller: true
  },
  {
    id: '7',
    name: 'DEER Punjabi 30',
    price: 2750,
    originalPrice: 3090,
    discountText: 'OFF 11%',
    statusText: 'Out Of Stock',
    viewCount: 95,
    category: 'Formal Wear',
    description: 'Modern black patterns.',
    images: ['https://images.unsplash.com/photo-1594938332152-4a00f1c911ee?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['M', 'L'],
    colors: ['White'],
    isNewArrival: true
  },
  {
    id: '8',
    name: 'Exclusive Punjabi 1',
    price: 1550,
    originalPrice: 1850,
    discountText: 'OFF 16.22%',
    statusText: 'Out Of Stock',
    viewCount: 142,
    category: 'Formal Wear',
    description: 'Limited edition design.',
    images: ['https://images.unsplash.com/photo-1594938332029-798881f37e41?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['L', 'XL'],
    colors: ['Gray']
  },
  {
    id: '9',
    name: 'DEER Punjabi 9',
    price: 3000,
    originalPrice: 3090,
    discountText: 'OFF 2.91%',
    statusText: 'Out Of Stock',
    viewCount: 567,
    category: 'Formal Wear',
    description: 'Classic navy silhouette.',
    images: ['https://images.unsplash.com/photo-1594938321683-149b80678822?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['M', 'L', 'XL'],
    colors: ['Navy']
  },
  {
    id: '10',
    name: 'MT Punjabi 4',
    price: 1550,
    originalPrice: 1950,
    discountText: 'OFF 20.51%',
    statusText: 'Out Of Stock',
    viewCount: 88,
    category: 'Formal Wear',
    description: 'Simple and elegant.',
    images: ['https://images.unsplash.com/photo-1594938321151-bed60ca18928?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['S', 'M'],
    colors: ['White']
  },
  {
    id: '5',
    name: 'Executive Silk Tie',
    price: 2200,
    category: 'Accessories',
    description: '100% pure silk tie.',
    images: ['https://images.unsplash.com/photo-1589756823851-91a67040772d?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['One Size'],
    colors: ['Gold', 'Black'],
    features: ['100% Silk']
  },
  {
    id: '6',
    name: 'Classic Khaki Shirt',
    price: 2950,
    category: 'Shirts',
    description: 'Breathable and elegant.',
    images: ['https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1000&auto=format&fit=crop'],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Khaki'],
    features: ['Premium Linen']
  }
];

export interface District {
  en: string;
  bn: string;
}

export interface DivisionData {
  bn: string;
  districts: District[];
}

export const BANGLADESH_DIVISIONS: Record<string, DivisionData> = {
  'Dhaka': {
    bn: 'Dhaka',
    districts: [
      { en: 'Dhaka', bn: 'Dhaka' },
      { en: 'Gazipur', bn: 'Gazipur' },
      { en: 'Narayanganj', bn: 'Narayanganj' },
      { en: 'Tangail', bn: 'Tangail' },
      { en: 'Faridpur', bn: 'Faridpur' },
      { en: 'Manikganj', bn: 'Manikganj' },
      { en: 'Munshiganj', bn: 'Munshiganj' },
      { en: 'Narsingdi', bn: 'Narsingdi' },
      { en: 'Rajbari', bn: 'Rajbari' },
      { en: 'Shariatpur', bn: 'Shariatpur' },
      { en: 'Madaripur', bn: 'Madaripur' },
      { en: 'Gopalganj', bn: 'Gopalganj' },
      { en: 'Kishoreganj', bn: 'Kishoreganj' }
    ]
  },
  'Chittagong': {
    bn: 'Chittagong',
    districts: [
      { en: 'Chittagong', bn: 'Chittagong' },
      { en: 'Cox\'s Bazar', bn: 'Cox\'s Bazar' },
      { en: 'Comilla', bn: 'Comilla' },
      { en: 'Feni', bn: 'Feni' },
      { en: 'Brahmanbaria', bn: 'Brahmanbaria' },
      { en: 'Noakhali', bn: 'Noakhali' },
      { en: 'Lakshmipur', bn: 'Lakshmipur' },
      { en: 'Chandpur', bn: 'Chandpur' },
      { en: 'Rangamati', bn: 'Rangamati' },
      { en: 'Khagrachhari', bn: 'Khagrachhari' },
      { en: 'Bandarban', bn: 'Bandarban' }
    ]
  },
  'Rajshahi': {
    bn: 'Rajshahi',
    districts: [
      { en: 'Rajshahi', bn: 'Rajshahi' },
      { en: 'Bogra', bn: 'Bogra' },
      { en: 'Pabna', bn: 'Pabna' },
      { en: 'Joypurhat', bn: 'Joypurhat' },
      { en: 'Naogaon', bn: 'Naogaon' },
      { en: 'Natore', bn: 'Natore' },
      { en: 'Chapainawabganj', bn: 'Chapainawabganj' },
      { en: 'Sirajganj', bn: 'Sirajganj' }
    ]
  },
  'Khulna': {
    bn: 'Khulna',
    districts: [
      { en: 'Khulna', bn: 'Khulna' },
      { en: 'Jessore', bn: 'Jessore' },
      { en: 'Satkhira', bn: 'Satkhira' },
      { en: 'Bagerhat', bn: 'Bagerhat' },
      { en: 'Kushtia', bn: 'Kushtia' },
      { en: 'Meherpur', bn: 'Meherpur' },
      { en: 'Chuadanga', bn: 'Chuadanga' },
      { en: 'Jhenaidah', bn: 'Jhenaidah' },
      { en: 'Magura', bn: 'Magura' },
      { en: 'Narail', bn: 'Narail' }
    ]
  },
  'Barishal': {
    bn: 'Barishal',
    districts: [
      { en: 'Barishal', bn: 'Barishal' },
      { en: 'Patuakhali', bn: 'Patuakhali' },
      { en: 'Bhola', bn: 'Bhola' },
      { en: 'Pirojpur', bn: 'Pirojpur' },
      { en: 'Jhalokati', bn: 'Jhalokati' },
      { en: 'Barguna', bn: 'Barguna' }
    ]
  },
  'Sylhet': {
    bn: 'Sylhet',
    districts: [
      { en: 'Sylhet', bn: 'Sylhet' },
      { en: 'Moulvibazar', bn: 'Moulvibazar' },
      { en: 'Habiganj', bn: 'Habiganj' },
      { en: 'Sunamganj', bn: 'Sunamganj' }
    ]
  },
  'Rangpur': {
    bn: 'Rangpur',
    districts: [
      { en: 'Rangpur', bn: 'Rangpur' },
      { en: 'Dinajpur', bn: 'Dinajpur' },
      { en: 'Gaibandha', bn: 'Gaibandha' },
      { en: 'Kurigram', bn: 'Kurigram' },
      { en: 'Lalmonirhat', bn: 'Lalmonirhat' },
      { en: 'Nilphamari', bn: 'Nilphamari' },
      { en: 'Panchagarh', bn: 'Panchagarh' },
      { en: 'Thakurgaon', bn: 'Thakurgaon' }
    ]
  },
  'Mymensingh': {
    bn: 'Mymensingh',
    districts: [
      { en: 'Mymensingh', bn: 'Mymensingh' },
      { en: 'Jamalpur', bn: 'Jamalpur' },
      { en: 'Netrokona', bn: 'Netrokona' },
      { en: 'Sherpur', bn: 'Sherpur' }
    ]
  }
};

export const ALL_BANGLADESH_DISTRICTS = Object.entries(BANGLADESH_DIVISIONS).flatMap(([divisionName, divisionData]) => 
  divisionData.districts.map(d => ({
    en: d.en,
    bn: d.bn,
    division: divisionName
  }))
).sort((a, b) => a.en.localeCompare(b.en));


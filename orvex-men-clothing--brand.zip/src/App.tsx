import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, Menu, ChevronRight, X, Eye, Mail, MapPin, Globe, ChevronDown, 
  ShoppingCart, ShoppingBag, LayoutGrid, Star, Instagram, Facebook, 
  MessageSquare, Plus, Trash2, Edit, Save, Lock, ArrowLeft, Check, AlertCircle, Zap,
  Loader2, CheckCircle2, Heart, ZoomIn
} from 'lucide-react';
import { products, categories, BANGLADESH_DIVISIONS, ALL_BANGLADESH_DISTRICTS } from './data';
import { Product, Review, CartItem, Order } from './types';
import { AdminPanel } from './components/AdminPanel';
import { supabase } from './supabase';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('Home');
  const [isLoading, setIsLoading] = useState(false);
  const [productFilter, setProductFilter] = useState('ALL');
  
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [reviewsByProduct, setReviewsByProduct] = useState<Record<string, Review[]>>({});
  
  const [newReview, setNewReview] = useState({ userName: '', rating: 5, comment: '' });
  const [isSupportOpen, setIsSupportOpen] = useState(false);

  // --- Dynamic Central States --
  const [productsList, setProductsList] = useState<Product[]>(() => {
    const saved = localStorage.getItem('orvex_products_list');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return products;
  });

  const handleUpdateProducts = async (newList: Product[]) => {
    setProductsList(newList);
    localStorage.setItem('orvex_products_list', JSON.stringify(newList));
    try {
      if (newList.length > 0) {
        await supabase.from('products').upsert(newList);
      }
    } catch (e) {
      console.error('Supabase sync error', e);
    }
  };

  const [categoriesList, setCategoriesList] = useState<any[]>(() => {
    const saved = localStorage.getItem('orvex_categories_list');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return categories;
  });

  const handleUpdateCategories = async (newList: any[]) => {
    setCategoriesList(newList);
    localStorage.setItem('orvex_categories_list', JSON.stringify(newList));
    try {
      if (newList.length > 0) {
        await supabase.from('categories').upsert(newList);
      }
    } catch (e) {
      console.error('Supabase sync error', e);
    }
  };

  // Cart and Order handling state
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('orvex_cart_items');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return [];
  });

  const handleUpdateCart = (newCart: CartItem[]) => {
    setCart(newCart);
    localStorage.setItem('orvex_cart_items', JSON.stringify(newCart));
  };

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('orvex_orders');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return [];
  });

  const handleUpdateOrders = async (newOrders: Order[]) => {
    setOrders(newOrders);
    localStorage.setItem('orvex_orders', JSON.stringify(newOrders));
    try {
      if (newOrders.length > 0) {
        await supabase.from('orders').upsert(newOrders);
      }
    } catch (e) {
      console.error('Supabase sync error', e);
    }
  };

  const [socialLinks, setSocialLinks] = useState(() => {
    const saved = localStorage.getItem('orvex_socials');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return {
      instagram: 'https://www.instagram.com/_orvex__?igsh=MXA3ZWZ0NXczNzRnOA==',
      facebook: 'https://www.facebook.com/dapperoutfitsbd',
      whatsapp: '01607369470',
      tiktok: 'https://www.tiktok.com/@orvex___?is_from_webapp=1&sender_device=pc',
      announcement: 'EID COLLECTION IS COMPLETED AND LIVE NOW. ENJOY ROYAL CUSTOM PREMIUM LUXURY EXPERIENCE!',
      storeAddress: 'Dhaka, Bangladesh',
      storePhone: '01607369470',
      heroBanner: ''
    };
  });

  const handleUpdateSocialLinks = async (newLinks: any) => {
    setSocialLinks(newLinks);
    localStorage.setItem('orvex_socials', JSON.stringify(newLinks));
    try {
      await supabase.from('social_links').upsert([{ id: '1', ...newLinks }]);
    } catch (e) {
      console.error('Supabase sync error', e);
    }
  };

  const [supportStaff, setSupportStaff] = useState(() => {
    const saved = localStorage.getItem('orvex_support_staff');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return [
      { id: '1', name: 'Masud Rana', icon: 'MR', phone: '01889662914', role: 'Sales & Styling Support' },
      { id: '2', name: 'Saiful Jaman', icon: 'SJ', phone: '01906139060', role: 'Order Tracking Help' },
      { id: '3', name: 'Eafin Hasan Siam', icon: 'ES', phone: '01816126195', role: 'Billing & Returns' }
    ];
  });

  const handleUpdateSupportStaff = async (newList: any[]) => {
    setSupportStaff(newList);
    localStorage.setItem('orvex_support_staff', JSON.stringify(newList));
    try {
      if (newList.length > 0) {
        await supabase.from('support_staff').upsert(newList);
      }
    } catch (e) {
      console.error('Supabase sync error', e);
    }
  };

  // Auth & Admin States
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => {
    const saved = localStorage.getItem('orvex_is_admin_logged');
    return saved === 'true';
  });

  const handleSetAdminLoggedIn = (status: boolean) => {
    setIsAdminLoggedIn(status);
    localStorage.setItem('orvex_is_admin_logged', String(status));
  };

  const [customerPhone, setCustomerPhone] = useState(() => {
    return localStorage.getItem('orvex_customer_phone') || '';
  });
  const [customerName, setCustomerName] = useState(() => {
    return localStorage.getItem('orvex_customer_name') || '';
  });
  const [customerPhoneInput, setCustomerPhoneInput] = useState('');
  const [customerNameInput, setCustomerNameInput] = useState('');
  const [customerLoginError, setCustomerLoginError] = useState('');
  const [authView, setAuthView] = useState<'customer' | 'admin'>('customer');

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCartAnimating, setIsCartAnimating] = useState(false);
  
  // Track Order States
  const [isTrackOrderOpen, setIsTrackOrderOpen] = useState(false);
  const [trackSearchQuery, setTrackSearchQuery] = useState(() => {
    return localStorage.getItem('orvex_last_track_query') || '';
  });
  const [trackActiveTab, setTrackActiveTab] = useState<'All' | 'Pending' | 'Approved' | 'Shipped' | 'Delivered' | 'Cancelled'>('All');
  const [searchedOrders, setSearchedOrders] = useState<Order[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  
  // Sync with Supabase on Mount
  useEffect(() => {
    const syncSupabase = async () => {
      try {
        // Products
        const { data: productsData } = await supabase.from('products').select('*');
        if (productsData && productsData.length > 0) {
          setProductsList(productsData);
          localStorage.setItem('orvex_products_list', JSON.stringify(productsData));
        } else if (productsList.length > 0) {
          await supabase.from('products').upsert(productsList);
        }

        // Categories
        const { data: categoriesData } = await supabase.from('categories').select('*');
        if (categoriesData && categoriesData.length > 0) {
          setCategoriesList(categoriesData);
          localStorage.setItem('orvex_categories_list', JSON.stringify(categoriesData));
        } else if (categoriesList.length > 0) {
          await supabase.from('categories').upsert(categoriesList);
        }

        // Orders
        const { data: ordersData } = await supabase.from('orders').select('*');
        if (ordersData && ordersData.length > 0) {
          setOrders(ordersData);
          localStorage.setItem('orvex_orders', JSON.stringify(ordersData));
        } else if (orders.length > 0) {
          await supabase.from('orders').upsert(orders);
        }

        // Social Links / Settings
        const { data: socialLinksData } = await supabase.from('social_links').select('*').eq('id', '1');
        if (socialLinksData && socialLinksData.length > 0) {
          setSocialLinks(socialLinksData[0]);
          localStorage.setItem('orvex_socials', JSON.stringify(socialLinksData[0]));
        } else {
          await supabase.from('social_links').upsert([{ id: '1', ...socialLinks }]);
        }

        // Support Staff
        const { data: supportStaffData } = await supabase.from('support_staff').select('*');
        if (supportStaffData && supportStaffData.length > 0) {
          setSupportStaff(supportStaffData);
          localStorage.setItem('orvex_support_staff', JSON.stringify(supportStaffData));
        } else if (supportStaff.length > 0) {
          await supabase.from('support_staff').upsert(supportStaff);
        }
      } catch (err) {
        console.error('Supabase sync error:', err);
      }
    };
    syncSupabase();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Checkout states
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutName, setCheckoutName] = useState('');
  const [checkoutPhone, setCheckoutPhone] = useState('');
  const [checkoutAltPhone, setCheckoutAltPhone] = useState('');
  const [checkoutAddress, setCheckoutAddress] = useState('');
  const [checkoutDistrict, setCheckoutDistrict] = useState('Dhaka');
  const [checkoutDivision, setCheckoutDivision] = useState('Dhaka');
  const [checkoutInstruction, setCheckoutInstruction] = useState('');
  const [shippingMethod, setShippingMethod] = useState<'inside' | 'outside'>('inside');
  const [isAddingNewAddress, setIsAddingNewAddress] = useState(false);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [isOrderSuccess, setIsOrderSuccess] = useState(false);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  // Wishlist State stored in localStorage
  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('orvex_wishlist');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return [];
  });
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  const toggleWishlist = (productId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setWishlist(prev => {
      const updated = prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId];
      localStorage.setItem('orvex_wishlist', JSON.stringify(updated));
      return updated;
    });
  };

  // Newsletter Subscription State stored in localStorage
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isNewsletterSubscribed, setIsNewsletterSubscribed] = useState(false);
  const [newsletterError, setNewsletterError] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setNewsletterError('');
    if (!newsletterEmail || !newsletterEmail.includes('@') || !newsletterEmail.includes('.')) {
      setNewsletterError('Please enter a valid email address.');
      return;
    }
    
    try {
      const existing = JSON.parse(localStorage.getItem('orvex_newsletter_emails') || '[]');
      if (!existing.includes(newsletterEmail.trim())) {
        existing.push(newsletterEmail.trim());
        localStorage.setItem('orvex_newsletter_emails', JSON.stringify(existing));
      }
    } catch(err) {
      localStorage.setItem('orvex_newsletter_emails', JSON.stringify([newsletterEmail.trim()]));
    }
    
    setIsNewsletterSubscribed(true);
    setNewsletterEmail('');
  };

  // Added to cart notification toast state
  const [lastAddedProduct, setLastAddedProduct] = useState<{
    id: string;
    name: string;
    price: number;
    image: string;
    size?: string;
    color?: string;
  } | null>(null);
  const [showAddedToast, setShowAddedToast] = useState(false);

  const handleAddToCart = (product: Product, size?: string, color?: string, openCart = false) => {
    const sizeVal = size || (product.sizes && product.sizes[0]) || 'One Size';
    const colVal = color || (product.colors && product.colors[0]) || 'Standard';

    const existing = cart.find(item => 
      item.id === product.id && 
      item.selectedSize === sizeVal && 
      item.selectedColor === colVal
    );

    let updatedCart: CartItem[];
    if (existing) {
      updatedCart = cart.map(item => 
        (item.id === product.id && item.selectedSize === sizeVal && item.selectedColor === colVal)
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
    } else {
      updatedCart = [...cart, {
        ...product,
        quantity: 1,
        selectedSize: sizeVal,
        selectedColor: colVal
      }];
    }

    handleUpdateCart(updatedCart);

    setLastAddedProduct({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: sizeVal,
      color: colVal
    });
    setShowAddedToast(true);
    
    // Trigger cart shake animation
    setIsCartAnimating(true);
    setTimeout(() => {
      setIsCartAnimating(false);
    }, 600);

    if (openCart) {
      setIsCartOpen(true);
    }
  };

  const handleBuyNow = (product: Product, size?: string, color?: string) => {
    const sizeVal = size || (product.sizes && product.sizes[0]) || 'One Size';
    const colVal = color || (product.colors && product.colors[0]) || 'Standard';

    handleAddToCart(product, sizeVal, colVal, false);
    setIsCartOpen(true);
    setIsCheckoutOpen(true);
  };

  // Saved Addresses state
  interface DeliveryAddress {
    id: string;
    alias: string;
    name: string;
    phone: string;
    altPhone?: string;
    address: string;
    district: string;
    division: string;
  }

  const [savedAddresses, setSavedAddresses] = useState<DeliveryAddress[]>(() => {
    const saved = localStorage.getItem('orvex_saved_addresses');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return [
      {
        id: 'default-home',
        alias: 'Home (Default Address)',
        name: 'Masud Rana',
        phone: '01607369470',
        altPhone: '01889662914',
        address: 'House 14, Road 5, Sector 3, Uttara',
        district: 'Dhaka - Uttara',
        division: 'Dhaka'
      }
    ];
  });

  const [selectedAddressId, setSelectedAddressId] = useState<string>('default-home');

  // Input states for new address form
  const [newAddressAlias, setNewAddressAlias] = useState('');
  const [newAddressName, setNewAddressName] = useState('');
  const [newAddressPhone, setNewAddressPhone] = useState('');
  const [newAddressAltPhone, setNewAddressAltPhone] = useState('');
  const [newAddressDetail, setNewAddressDetail] = useState('');
  const [newAddressDistrict, setNewAddressDistrict] = useState('Dhaka');
  const [newAddressDivision, setNewAddressDivision] = useState('Dhaka');

  // Sync selected address to form helper
  const handleSelectAddress = (id: string) => {
    setSelectedAddressId(id);
    const addr = savedAddresses.find(a => a.id === id);
    if (addr) {
      setCheckoutName(addr.name);
      setCheckoutPhone(addr.phone);
      setCheckoutAltPhone(addr.altPhone || '');
      setCheckoutAddress(addr.address);
      setCheckoutDistrict(addr.district);
      setCheckoutDivision(addr.division);
      if (addr.district === 'Gazipur') {
        setShippingMethod('inside');
      } else {
        setShippingMethod('outside');
      }
    }
  };

  const handleAddNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddressName || !newAddressPhone || !newAddressDetail || !newAddressDistrict) return;
    const newAddr: DeliveryAddress = {
      id: Date.now().toString(),
      alias: newAddressAlias.trim() || `My Address ${savedAddresses.length + 1}`,
      name: newAddressName,
      phone: newAddressPhone,
      altPhone: newAddressAltPhone,
      address: newAddressDetail,
      district: newAddressDistrict,
      division: newAddressDivision
    };
    
    const updated = [...savedAddresses, newAddr];
    setSavedAddresses(updated);
    localStorage.setItem('orvex_saved_addresses', JSON.stringify(updated));
    
    setSelectedAddressId(newAddr.id);
    setCheckoutName(newAddr.name);
    setCheckoutPhone(newAddr.phone);
    setCheckoutAltPhone(newAddr.altPhone || '');
    setCheckoutAddress(newAddr.address);
    setCheckoutDistrict(newAddr.district);
    setCheckoutDivision(newAddr.division);
    if (newAddr.district === 'Gazipur') {
      setShippingMethod('inside');
    } else {
      setShippingMethod('outside');
    }

    setNewAddressAlias('');
    setNewAddressName('');
    setNewAddressPhone('');
    setNewAddressAltPhone('');
    setNewAddressDetail('');
    setNewAddressDistrict('Dhaka');
    setNewAddressDivision('Dhaka');
    setIsAddingNewAddress(false);
  };

  useEffect(() => {
    const addr = savedAddresses.find(a => a.id === selectedAddressId);
    if (addr) {
      setCheckoutName(addr.name);
      setCheckoutPhone(addr.phone);
      setCheckoutAltPhone(addr.altPhone || '');
      setCheckoutAddress(addr.address);
      setCheckoutDistrict(addr.district);
      setCheckoutDivision(addr.division);
      if (addr.district === 'Gazipur') {
        setShippingMethod('inside');
      } else {
        setShippingMethod('outside');
      }
    }
  }, [selectedAddressId, savedAddresses]);

  // Track Order Filter Effect
  useEffect(() => {
    const q = trackSearchQuery.trim().toLowerCase();
    if (q) {
      const results = orders.filter(o => 
        o.id.toLowerCase() === q || 
        o.customerPhone.replace(/[\s-+]/g, '').includes(q.replace(/[\s-+]/g, '')) ||
        (o.customerAltPhone && o.customerAltPhone.replace(/[\s-+]/g, '').includes(q.replace(/[\s-+]/g, '')))
      );
      setSearchedOrders(results);
      setHasSearched(true);
    } else {
      // Auto-show all orders placed on this browser/machine if no search query is typed!
      setSearchedOrders(orders);
      setHasSearched(true);
    }
  }, [trackSearchQuery, orders]);
  
  // Custom states for single product color/size selection
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');

  // Hover-to-zoom & Product image gallery state
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [zoomPos, setZoomPos] = useState({ x: 50, y: 50, isHovered: false });

  const handleMouseMoveZoom = (e: React.MouseEvent<HTMLDivElement>) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(100, ((e.clientX - left) / width) * 100));
    const y = Math.max(0, Math.min(100, ((e.clientY - top) / height) * 100));
    setZoomPos({ x, y, isHovered: true });
  };

  const handleMouseLeaveZoom = () => {
    setZoomPos(prev => ({ ...prev, isHovered: false }));
  };

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setActiveImageIndex(0);
    setZoomPos({ x: 50, y: 50, isHovered: false });
    setSelectedSize(product.sizes && product.sizes.length > 0 ? product.sizes[0] : 'One Size');
    setSelectedColor(product.colors && product.colors.length > 0 ? product.colors[0] : 'Standard');
    window.scrollTo(0, 0);
  };
  
  const handleCloseProduct = () => {
    setSelectedProduct(null);
    setActiveImageIndex(0);
    setZoomPos({ x: 50, y: 50, isHovered: false });
    window.scrollTo(0, 0);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || !newReview.userName || !newReview.comment) return;

    const review: Review = {
      id: Date.now().toString(),
      userName: newReview.userName,
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toLocaleDateString()
    };

    setReviewsByProduct(prev => ({
      ...prev,
      [selectedProduct.id]: [review, ...(prev[selectedProduct.id] || [])]
    }));

    setNewReview({ userName: '', rating: 5, comment: '' });
  };

  const maxAllowedPrice = 5000;
  
  // Filter States
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(maxAllowedPrice);

  const [selectedCategories, setSelectedCategories] = useState<string[]>(['All']);
  
  const [isSizeExpanded, setIsSizeExpanded] = useState(true);
  const [selectedSizes, setSelectedSizes] = useState<string[]>(['All']);
  
  const [isDiscountExpanded, setIsDiscountExpanded] = useState(false);
  const [selectedDiscounts, setSelectedDiscounts] = useState<string[]>(['All']);

  const [isColorExpanded, setIsColorExpanded] = useState(false);
  const [selectedColors, setSelectedColors] = useState<string[]>(['All']);

  const [searchQuery, setSearchQuery] = useState('');

  const handleFilterToggle = (
    value: string, 
    selectedList: string[], 
    setSelectedList: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    if (value === 'All') {
      setSelectedList(['All']);
    } else {
      let filtered = selectedList.filter(item => item !== 'All');
      if (filtered.includes(value)) {
        filtered = filtered.filter(item => item !== value);
        if (filtered.length === 0) filtered = ['All'];
      } else {
        filtered.push(value);
      }
      setSelectedList(filtered);
    }
  };

  const handleResetFilters = () => {
    setMinPrice(0);
    setMaxPrice(maxAllowedPrice);
    setSelectedCategories(['All']);
    setSelectedSizes(['All']);
    setSelectedDiscounts(['All']);
    setSelectedColors(['All']);
    setSearchQuery('');
  };

  const navigateToCategory = (category: string) => {
    setSelectedProduct(null);
    handleResetFilters();
    setSelectedCategories([category]);
    setIsLoading(true);
    setActiveTab('Our Products');
    window.scrollTo(0, 0);
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  const handleNavigation = (tab: string) => {
    setSelectedProduct(null);
    if (tab === 'Our Products') {
      handleResetFilters();
    }
    
    if (tab === 'Home' || tab === 'Contact Us' || tab === 'About Us') {
      setActiveTab(tab);
      window.scrollTo(0, 0);
    } else {
      setIsLoading(true);
      setActiveTab(tab);
      window.scrollTo(0, 0);
      setTimeout(() => {
        setIsLoading(false);
      }, 1000);
    }
  };

  // Slider refs
  const sliderRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const startX = useRef(0);
  const scrollLeft = useRef(0);
  const scrollDirection = useRef<1 | -1>(1); 
  const lastX = useRef(0);
  const scrollPos = useRef(0);

  useEffect(() => {
    const slider = sliderRef.current;
    if (!slider) return;

    let animationFrameId: number;

    // Initialize scrollPos to the middle set to allow immediate scrolling in either direction
    const exactSetWidth = (slider.children[categoriesList.length] as HTMLElement)?.offsetLeft;
    if (exactSetWidth) {
      slider.scrollLeft = exactSetWidth;
      scrollPos.current = slider.scrollLeft;
    }

    const autoScroll = () => {
      if (!isDragging.current) {
        scrollPos.current += scrollDirection.current * 0.7; // adjust speed here
        
        const setWidth = (slider.children[categoriesList.length] as HTMLElement)?.offsetLeft;
        if (setWidth) {
          // Seamless loop
          if (scrollPos.current >= setWidth * 2) {
             scrollPos.current -= setWidth;
          } else if (scrollPos.current <= 0) {
             scrollPos.current += setWidth;
          }
        }
        slider.scrollLeft = scrollPos.current;
      } else {
        // synchronize scrollPos with the actual drag position
        scrollPos.current = slider.scrollLeft;
      }
      animationFrameId = requestAnimationFrame(autoScroll);
    };

    animationFrameId = requestAnimationFrame(autoScroll);
    return () => cancelAnimationFrame(animationFrameId);
  }, [activeTab]);

  const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
    if (!sliderRef.current) return;
    isDragging.current = true;
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    startX.current = clientX - sliderRef.current.offsetLeft;
    scrollLeft.current = sliderRef.current.scrollLeft;
    lastX.current = clientX;
    sliderRef.current.style.cursor = 'grabbing';
  };

  const handleDragMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDragging.current || !sliderRef.current) return;
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const x = clientX - sliderRef.current.offsetLeft;
    const walk = (x - startX.current) * 1.5;
    sliderRef.current.scrollLeft = scrollLeft.current - walk;
    scrollPos.current = sliderRef.current.scrollLeft;
    
    if (clientX < lastX.current) {
       scrollDirection.current = 1; // Dragging left, content moves left
    } else if (clientX > lastX.current) {
       scrollDirection.current = -1; // Dragging right, content moves right
    }
    lastX.current = clientX;
  };

  const handleDragEnd = () => {
    isDragging.current = false;
    if (sliderRef.current) sliderRef.current.style.cursor = 'grab';
  };

  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (authEmail.trim().toLowerCase() === 'dapper.outfits12@gmail.com' && authPassword === 'dapper123') {
      handleSetAdminLoggedIn(true);
      setIsAuthModalOpen(false);
      setAuthError('');
      setAuthEmail('');
      setAuthPassword('');
    } else {
      setAuthError('Invalid credentials. Password is "dapper123". Please check and try again.');
    }
  };

  if (isAdminLoggedIn) {
    return (
      <AdminPanel 
        products={productsList}
        onUpdateProducts={handleUpdateProducts}
        categories={categoriesList}
        onUpdateCategories={handleUpdateCategories}
        orders={orders}
        onUpdateOrders={handleUpdateOrders}
        supportStaff={supportStaff}
        onUpdateSupportStaff={handleUpdateSupportStaff}
        socialLinks={socialLinks}
        onUpdateSocialLinks={handleUpdateSocialLinks}
        onClose={() => handleSetAdminLoggedIn(false)}
      />
    );
  }

  return (
    <div className="min-h-screen relative flex flex-col bg-black text-gray-200">
      {/* Loading Overlay */}
      {isLoading && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center">
          <div className="flex flex-col items-center gap-6 animate-pulse">
            <img 
              src="/Orvex.png.png" 
              alt="Orvex Logo" 
              className="h-48 md:h-72 object-contain"
            />
            <div className="w-48 h-1 bg-gray-800 rounded-full overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-full bg-gold rounded-full animate-progress"></div>
            </div>
          </div>
        </div>
      )}

      {/* Top Bar */}
      <div className="bg-black text-gray-300 text-[11px] font-semibold tracking-wider py-3 hidden lg:block border-b border-[#2a2a2a] w-full z-50 fixed top-0 h-10">
        <div className="max-w-[1600px] mx-auto px-4 flex justify-between items-center h-full">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2 hover:text-gold cursor-pointer transition-colors"><Mail size={14} /> Support</span>
            <span className="text-gray-600">|</span>
            <span className="flex items-center gap-2 hover:text-gold cursor-pointer transition-colors" title={socialLinks.storeAddress}><MapPin size={14} /> {socialLinks.storeAddress}</span>
          </div>
          <div className="flex items-center tracking-normal uppercase font-mono font-bold text-gray-205">
            {socialLinks.announcement}
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 cursor-pointer hover:text-gold transition-colors">
              <Globe size={14} /> Bangla <ChevronDown size={14} />
            </span>
            <span className="text-gray-600">|</span>
            <span className="cursor-pointer hover:text-gold transition-colors">Registration</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="fixed top-0 lg:top-10 w-full z-40 bg-[rgba(0,0,0,0.9)] backdrop-blur-md border-b border-gray-800 transition-all duration-300">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-[85px]">
            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-white hover:text-gold transition-colors">
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>

            {/* Logo */}
            <div className="flex-shrink-0 flex items-center gap-3 cursor-pointer" onClick={() => handleNavigation('Home')}>
              <img 
                src="/Orvex.png.png" 
                alt="Orvex Logo" 
                className="h-12 w-auto md:h-16 object-contain hidden"
                onLoad={(e) => {
                  e.currentTarget.classList.remove('hidden');
                }}
                onError={(e) => {
                  e.currentTarget.classList.add('hidden');
                }}
              />
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-8">
              {['Home', 'Our Products', 'Categories', 'Contact Us', 'About Us'].map((item) => (
                <button
                  key={item}
                  onClick={() => handleNavigation(item)}
                  className={`text-[15px] font-bold tracking-wide transition-all hover:text-gold relative group ${
                    activeTab === item ? 'text-gold' : 'text-gray-300'
                  }`}
                >
                  {item}
                  <span className={`absolute -bottom-1.5 left-0 h-[2px] bg-gold transition-all duration-300 ${activeTab === item ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                </button>
              ))}
            </div>

            {/* Icons */}
            <div className="flex items-center space-x-3 md:space-x-5">
              <button className="text-gray-300 hover:text-gold transition-colors">
                <Search size={22} />
              </button>
              <button 
                onClick={() => setIsWishlistOpen(true)}
                className="text-gray-300 hover:text-gold transition-colors relative cursor-pointer"
                title="View Wishlist"
              >
                <Heart size={22} className={wishlist.length > 0 ? "text-red-500 fill-red-500/20" : ""} />
                {wishlist.length > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 inline-flex items-center justify-center min-w-[20px] h-[20px] text-[11px] font-bold text-white bg-red-600 rounded-full px-1 shadow-sm animate-pulse">
                    {wishlist.length}
                  </span>
                )}
              </button>
              <button 
                onClick={() => setIsCartOpen(true)}
                className={`text-gray-300 hover:text-gold transition-colors relative ${isCartAnimating ? 'animate-shake' : ''}`}
              >
                <ShoppingCart size={22} className={isCartAnimating ? 'text-gold' : ''} />
                <span className="absolute -top-1.5 -right-2.5 inline-flex items-center justify-center min-w-[20px] h-[20px] text-[11px] font-bold text-black bg-gold rounded-full px-1 shadow-sm">
                  {cart.length}
                </span>
              </button>
              <button 
                onClick={() => setIsAuthModalOpen(true)}
                className="hidden sm:block bg-gold hover:bg-opacity-90 text-black px-6 py-2.5 rounded shadow-sm font-semibold tracking-wide transition-colors"
              >
                {isAdminLoggedIn ? 'Admin Panel' : customerPhone ? 'My Account' : 'Login'}
              </button>
            </div>
          </div>
        </div>

        {/* Top Cart Added Toast Notification */}
        {showAddedToast && lastAddedProduct && (
          <div className="fixed top-20 right-3 md:right-8 z-50 bg-[#111] border border-gold/40 text-white rounded-xl p-3.5 shadow-2xl max-w-xs md:max-w-sm font-sans animate-fade-in-up">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <img src={lastAddedProduct.image} alt={lastAddedProduct.name} className="w-12 h-14 object-cover rounded bg-gray-900 border border-gray-800 shrink-0" />
                <div className="text-left">
                  <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider flex items-center gap-1 font-mono">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                    ✓ Added To Shopping Cart!
                  </span>
                  <h5 className="font-bold text-xs text-white uppercase line-clamp-1 mt-0.5">{lastAddedProduct.name}</h5>
                  <p className="text-[11px] text-gold font-mono font-bold">Tk {lastAddedProduct.price} <span className="text-gray-400 text-[9px] font-normal">({lastAddedProduct.size || 'Size'}, {lastAddedProduct.color || 'Color'})</span></p>
                </div>
              </div>
              <button onClick={() => setShowAddedToast(false)} className="text-gray-400 hover:text-white p-1">
                <X size={16} />
              </button>
            </div>
            <div className="flex gap-2 mt-3 pt-2 border-t border-gray-850">
              <button 
                onClick={() => { setShowAddedToast(false); setIsCartOpen(true); }}
                className="flex-1 bg-black hover:bg-gray-900 border border-gray-700 text-white text-[10px] font-bold py-1.5 rounded uppercase tracking-wider transition-colors cursor-pointer"
              >
                View Bag ({cart.length})
              </button>
              <button 
                onClick={() => { setShowAddedToast(false); setIsCartOpen(true); setIsCheckoutOpen(true); }}
                className="flex-1 bg-gold hover:bg-opacity-90 text-black text-[10px] font-black py-1.5 rounded uppercase tracking-wider transition-colors cursor-pointer"
              >
                Buy Now
              </button>
            </div>
          </div>
        )}

        {/* Mobile Menu Content */}
        {isMenuOpen && (
          <div className="md:hidden bg-[#111] border-b border-gray-800 absolute w-full left-0 z-40">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 shadow-lg">
              {['Home', 'Our Products', 'Categories', 'Contact Us', 'About Us'].map((item) => (
                <button
                  key={item}
                  onClick={() => {
                    handleNavigation(item);
                    setIsMenuOpen(false);
                  }}
                  className={`block w-full text-left px-3 py-2 text-base font-bold tracking-wide ${
                    activeTab === item ? 'text-gold' : 'text-gray-300 hover:text-gold'
                  }`}
                >
                  {item}
                </button>
              ))}
               <button 
                onClick={() => {
                  setIsAuthModalOpen(true);
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 text-base font-bold tracking-wide text-charcoal uppercase bg-gold mt-2 rounded cursor-pointer text-center"
              >
                {isAdminLoggedIn ? 'Admin Panel' : customerPhone ? 'My Account' : 'Login'}
              </button>
            </div>
          </div>
        )}
      </nav>

      <main className="flex-grow pt-[85px] lg:pt-[125px]">
        {selectedProduct ? (
          <div className="bg-black min-h-screen py-10">
            <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
              <button 
                onClick={handleCloseProduct}
                className="mb-8 flex items-center gap-2 text-gray-400 hover:text-gold transition-colors"
              >
                <X size={20} /> Back to Products
              </button>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="flex flex-col gap-4">
                  {/* Interactive Hover-To-Zoom Main Image Container */}
                  <div 
                    className="relative aspect-[3/4] bg-gray-900 rounded-xl overflow-hidden border border-gray-800 cursor-crosshair group select-none shadow-2xl"
                    onMouseMove={handleMouseMoveZoom}
                    onMouseLeave={handleMouseLeaveZoom}
                    onTouchMove={(e) => {
                      const touch = e.touches[0];
                      if (touch && e.currentTarget) {
                        const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
                        const x = Math.max(0, Math.min(100, ((touch.clientX - left) / width) * 100));
                        const y = Math.max(0, Math.min(100, ((touch.clientY - top) / height) * 100));
                        setZoomPos({ x, y, isHovered: true });
                      }
                    }}
                    onTouchEnd={handleMouseLeaveZoom}
                  >
                    <img 
                      src={selectedProduct.images[activeImageIndex] || selectedProduct.images[0]} 
                      alt={selectedProduct.name}
                      className={`w-full h-full object-cover transition-transform duration-150 ease-out origin-center ${
                        zoomPos.isHovered ? 'scale-[2.4]' : 'scale-100'
                      }`}
                      style={{
                        transformOrigin: zoomPos.isHovered ? `${zoomPos.x}% ${zoomPos.y}%` : 'center center'
                      }}
                    />

                    {/* Instruction Pill (Fades out when zooming) */}
                    <div className={`absolute bottom-3 left-3 bg-black/80 backdrop-blur-md text-gold text-[11px] font-bold px-3 py-1.5 rounded-full border border-gold/30 flex items-center gap-1.5 transition-opacity duration-200 pointer-events-none shadow-lg ${
                      zoomPos.isHovered ? 'opacity-0' : 'opacity-100'
                    }`}>
                      <ZoomIn size={14} className="animate-pulse" />
                      <span>Hover image to inspect fabric & details</span>
                    </div>

                    {/* Active Zoom Badge */}
                    {zoomPos.isHovered && (
                      <div className="absolute top-3 right-3 bg-gold text-black text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded shadow-lg pointer-events-none flex items-center gap-1 animate-in fade-in duration-200">
                        <ZoomIn size={12} />
                        <span>2.4x Zoomed</span>
                      </div>
                    )}
                  </div>

                  {/* Thumbnails Gallery (for multi-image products) */}
                  {selectedProduct.images && selectedProduct.images.length > 1 && (
                    <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-none">
                      {selectedProduct.images.map((imgUrl, idx) => (
                        <button
                          key={idx}
                          onClick={() => setActiveImageIndex(idx)}
                          className={`relative w-18 h-24 rounded-lg overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                            activeImageIndex === idx ? 'border-gold ring-2 ring-gold/30 scale-105' : 'border-gray-800 opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img src={imgUrl} alt={`${selectedProduct.name} ${idx + 1}`} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                
                <div className="flex flex-col text-gray-200">
                  <h2 className="text-3xl font-black text-white uppercase tracking-wider mb-2">{selectedProduct.name}</h2>
                  <div className="text-2xl font-bold text-gold mb-6">Tk {selectedProduct.price}</div>
                  
                  <div className="mb-6 pb-6 border-b border-gray-800">
                    <p className="text-gray-400 text-sm leading-relaxed">{selectedProduct.description}</p>
                  </div>

                  {/* Dynamic Size Picker */}
                  {(() => {
                    const isPant = selectedProduct.name.toLowerCase().includes('pant') || 
                                   selectedProduct.name.toLowerCase().includes('chino') || 
                                   selectedProduct.name.toLowerCase().includes('cargo') || 
                                   selectedProduct.name.toLowerCase().includes('jean') || 
                                   selectedProduct.name.toLowerCase().includes('trouser');
                    
                    const finalSizes = isPant 
                      ? ['28', '29', '30', '31', '32', '33', '34', '35'] 
                      : (selectedProduct.sizes && selectedProduct.sizes.length > 0 ? selectedProduct.sizes : ['S', 'M', 'L', 'XL']);

                    return (
                      <div className="mb-6 font-sans">
                        <span className="text-xs uppercase tracking-wider text-gray-500 font-bold block mb-2 font-mono">Select Size:</span>
                        <div className="flex flex-wrap gap-2">
                          {finalSizes.map(size => (
                            <button
                              key={size}
                              type="button"
                              onClick={() => setSelectedSize(size)}
                              className={`px-4 py-2 text-xs font-bold border transition-all rounded cursor-pointer ${
                                selectedSize === size
                                  ? 'bg-gold text-black border-gold shadow-md shadow-gold/20'
                                  : 'bg-black border-gray-800 text-gray-300 hover:border-gray-500'
                              }`}
                            >
                              {size}
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })()}

                  {/* Dynamic Color Picker */}
                  {selectedProduct.colors && selectedProduct.colors.length > 0 && (
                    <div className="mb-8">
                      <span className="text-xs uppercase tracking-wider text-gray-500 font-bold block mb-2 font-mono">Select Color:</span>
                      <div className="flex flex-wrap gap-2">
                        {selectedProduct.colors.map(color => (
                          <button
                            key={color}
                            onClick={() => setSelectedColor(color)}
                            className={`px-4 py-2 text-xs font-bold border transition-all rounded cursor-pointer ${
                              selectedColor === color
                                ? 'bg-white text-black border-white shadow-md'
                                : 'bg-black border-gray-800 text-gray-300 hover:border-gray-500'
                            }`}
                          >
                            {color}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Action Buttons: Buy Now & Add to Cart & Wishlist */}
                  <div className="flex flex-col sm:flex-row gap-3 mb-12">
                    <button 
                      onClick={() => handleBuyNow(selectedProduct, selectedSize, selectedColor)}
                      className="flex-1 bg-gold hover:bg-opacity-95 text-black py-4 px-6 rounded font-black uppercase tracking-wider text-sm shadow-xl flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
                    >
                      <Zap size={18} /> Buy Now
                    </button>
                    <button 
                      onClick={() => handleAddToCart(selectedProduct, selectedSize, selectedColor, true)}
                      className="flex-1 bg-[#ed3237] hover:bg-[#d52b30] text-white py-4 px-6 rounded font-extrabold uppercase tracking-wider text-sm shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
                    >
                      <ShoppingBag size={18} /> Add to Cart
                    </button>
                    <button 
                      onClick={(e) => toggleWishlist(selectedProduct.id, e)}
                      className={`px-5 py-4 rounded font-extrabold border flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        wishlist.includes(selectedProduct.id)
                          ? 'bg-red-500/20 border-red-500 text-red-500'
                          : 'bg-[#111] border-gray-800 text-gray-300 hover:border-gold hover:text-gold'
                      }`}
                      title={wishlist.includes(selectedProduct.id) ? "Remove from Wishlist" : "Add to Wishlist"}
                    >
                      <Heart size={20} className={wishlist.includes(selectedProduct.id) ? "fill-red-500 text-red-500" : ""} />
                      <span className="sm:hidden text-xs uppercase tracking-wider">Wishlist</span>
                    </button>
                  </div>

                  <div className="mt-8">
                    <h3 className="text-xl font-bold text-white mb-6 uppercase tracking-wider">Customer Reviews</h3>
                    
                    {/* Review Form */}
                    <form onSubmit={handleReviewSubmit} className="mb-10 bg-[#111] p-6 rounded-lg border border-gray-800">
                      <h4 className="text-lg font-bold text-white mb-4">Write a Review</h4>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Name</label>
                          <input 
                            type="text" 
                            value={newReview.userName}
                            onChange={e => setNewReview({...newReview, userName: e.target.value})}
                            required
                            className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-gold transition-colors"
                          />
                        </div>
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Rating</label>
                          <select 
                            value={newReview.rating}
                            onChange={e => setNewReview({...newReview, rating: Number(e.target.value)})}
                            className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-gold transition-colors"
                          >
                            {[5, 4, 3, 2, 1].map(num => (
                              <option key={num} value={num}>{num} Star{num !== 1 ? 's' : ''}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Review</label>
                          <textarea 
                            value={newReview.comment}
                            onChange={e => setNewReview({...newReview, comment: e.target.value})}
                            required
                            rows={3}
                            className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-gold transition-colors"
                          ></textarea>
                        </div>
                        <button type="submit" className="bg-[#D4AF37] hover:bg-[#A6892C] text-black py-2 px-6 rounded font-bold transition-all shadow-lg text-sm">
                          Submit Review
                        </button>
                      </div>
                    </form>

                    {/* Review List */}
                    <div className="space-y-4">
                      {reviewsByProduct[selectedProduct.id] && reviewsByProduct[selectedProduct.id].length > 0 ? (
                        reviewsByProduct[selectedProduct.id].map(review => (
                          <div key={review.id} className="bg-[#111] p-4 rounded-lg border border-gray-800">
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-bold text-white">{review.userName}</span>
                              <span className="text-xs text-gray-500">{review.date}</span>
                            </div>
                            <div className="flex gap-1 mb-2">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  size={14} 
                                  className={i < review.rating ? "text-gold fill-gold" : "text-gray-700"} 
                                />
                              ))}
                            </div>
                            <p className="text-sm text-gray-400">{review.comment}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-gray-500 text-sm italic">No reviews yet. Be the first to review!</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <>
            {activeTab === 'Our Products' && (
          <div className="bg-black min-h-screen py-10">
            <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row gap-8">
              {/* Mobile Filter Toggle Button */}
              <div className="lg:hidden mb-1">
                <button 
                  onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)} 
                  className="w-full flex items-center justify-between bg-[#111] border border-gray-800 hover:border-gold rounded-lg p-3 text-white font-bold text-xs uppercase tracking-wider shadow-md transition-all active:scale-[0.99]"
                >
                  <div className="flex items-center gap-2">
                    <Search size={15} className="text-gold" />
                    <span>Filter & Search</span>
                    {(selectedCategories.length > 1 || !selectedCategories.includes('All') || searchQuery || minPrice > 0 || !selectedSizes.includes('All') || !selectedColors.includes('All')) && (
                      <span className="w-2 h-2 rounded-full bg-gold animate-pulse"></span>
                    )}
                  </div>
                  <ChevronDown size={16} className={`text-gold transition-transform duration-300 ${isMobileFilterOpen ? 'rotate-180' : ''}`} />
                </button>
              </div>

              {/* Sidebar Filter */}
              <div className={`w-full lg:w-72 flex-shrink-0 ${isMobileFilterOpen ? 'block' : 'hidden lg:block'}`}>
                <div className="bg-[#111] border border-gray-800 rounded-lg p-5 sticky top-36">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-bold text-white">Filter</h3>
                    <button onClick={handleResetFilters} className="text-[#ed3237] text-sm font-semibold hover:underline">Clear all</button>
                  </div>
                  
                  <div className="mb-6">
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="Search product..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-black border border-gray-700 text-white px-4 py-2.5 rounded text-sm focus:outline-none focus:border-gold" 
                      />
                      <Search size={16} className="absolute right-3 top-3 text-gray-500" />
                    </div>
                  </div>
                  
                  <div className="mb-6 pb-6 border-b border-gray-800">
                    <h4 className="font-bold text-white mb-4">Price</h4>
                    <div className="flex justify-between text-xs text-gray-400 mb-2 font-medium">
                      <span>Min Price: Tk {minPrice}</span>
                      <span>Max Price: Tk {maxPrice}</span>
                    </div>
                    <div className="relative mt-3 h-5">
                      <div className="absolute top-1/2 -translate-y-1/2 left-0 w-full h-1.5 bg-gray-700 rounded-full"></div>
                      <div 
                        className="absolute top-1/2 -translate-y-1/2 h-1.5 bg-[#ed3237] rounded-full pointer-events-none"
                        style={{ 
                          left: `${(minPrice / maxAllowedPrice) * 100}%`, 
                          right: `${100 - (maxPrice / maxAllowedPrice) * 100}%` 
                        }}
                      ></div>
                      <input 
                        type="range" 
                        min="0" 
                        max={maxAllowedPrice} 
                        step="100"
                        value={minPrice} 
                        onChange={(e) => {
                            const val = parseInt(e.target.value);
                            if (val <= maxPrice) setMinPrice(val);
                        }}
                        className="absolute top-1/2 -translate-y-1/2 left-0 w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4.5 [&::-webkit-slider-thumb]:h-4.5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-[#ed3237] [&::-webkit-slider-thumb]:shadow cursor-pointer"
                      />
                      <input 
                        type="range" 
                        min="0" 
                        max={maxAllowedPrice} 
                        step="100"
                        value={maxPrice} 
                        onChange={(e) => {
                            const val = parseInt(e.target.value);
                            if (val >= minPrice) setMaxPrice(val);
                        }}
                        className="absolute top-1/2 -translate-y-1/2 left-0 w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4.5 [&::-webkit-slider-thumb]:h-4.5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-[#ed3237] [&::-webkit-slider-thumb]:shadow cursor-pointer"
                      />
                    </div>
                  </div>

                  <div className="mb-6 pb-6 border-b border-gray-800">
                    <h4 className="font-bold text-white mb-4">Categories</h4>
                    <div className="space-y-3">
                      {['All', 'Shirt', 'Pant', 'Hoodie', 'Polo Sweatshirt', 'Sweatshirt', 'Shoe', 'Jacket', 'Combo', 'T-shirt', 'Panjabi'].map((cat) => (
                        <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                          <input 
                            type="checkbox" 
                            checked={selectedCategories.includes(cat)}
                            onChange={() => handleFilterToggle(cat, selectedCategories, setSelectedCategories)}
                            className="w-4 h-4 rounded-sm bg-black border-gray-600 text-[#D4AF37] accent-[#D4AF37] focus:ring-[#D4AF37] focus:ring-offset-0 focus:ring-1" 
                          />
                          <span className="text-gray-300 text-sm group-hover:text-white transition-colors">{cat}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="mb-6 pb-6 border-b border-gray-800">
                    <div className="flex justify-between items-center mb-4 cursor-pointer group" onClick={() => setIsSizeExpanded(!isSizeExpanded)}>
                      <h4 className="font-bold text-white group-hover:text-gold transition-colors">Size</h4>
                      <ChevronDown size={16} className={`text-gray-500 group-hover:text-white transition-transform ${isSizeExpanded ? 'rotate-180' : ''}`} />
                    </div>
                    {isSizeExpanded && (
                      <div className="grid grid-cols-4 gap-2">
                        {['All', 'S', 'M', 'L', 'XL', 'XXL', '28', '30', '32', '34', '36', '38', '39', '40', '41', '42', '43', '44'].map((size) => {
                          const isSelected = selectedSizes.includes(size);
                          return (
                            <button 
                              key={size} 
                              onClick={() => handleFilterToggle(size, selectedSizes, setSelectedSizes)}
                              className={`py-1.5 text-[11px] font-medium rounded border text-center transition-colors ${isSelected ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-700 text-gray-400 hover:border-gray-500 hover:text-gray-200'}`}>
                              {size}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  <div className="mb-6 pb-6 border-b border-gray-800">
                    <div className="flex justify-between items-center mb-4 cursor-pointer group" onClick={() => setIsDiscountExpanded(!isDiscountExpanded)}>
                      <h4 className="font-bold text-white group-hover:text-gold transition-colors">Discount Range</h4>
                      <ChevronDown size={16} className={`text-gray-500 group-hover:text-white transition-transform ${isDiscountExpanded ? 'rotate-180' : ''}`} />
                    </div>
                    {isDiscountExpanded && (
                      <div className="space-y-3">
                        {['All', 'Up to 10%', 'Up to 20%', 'Up to 30%', 'Up to 50%'].map((range) => (
                          <label key={range} className="flex items-center gap-3 cursor-pointer group">
                            <input 
                              type="checkbox" 
                              checked={selectedDiscounts.includes(range)}
                              onChange={() => handleFilterToggle(range, selectedDiscounts, setSelectedDiscounts)}
                              className="w-4 h-4 rounded-sm bg-black border-gray-600 text-[#D4AF37] accent-[#D4AF37] focus:ring-[#D4AF37] focus:ring-offset-0 focus:ring-1" 
                            />
                            <span className="text-gray-300 text-sm group-hover:text-white transition-colors">{range}</span>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-4 cursor-pointer group" onClick={() => setIsColorExpanded(!isColorExpanded)}>
                      <h4 className="font-bold text-white group-hover:text-gold transition-colors">Colors</h4>
                      <ChevronDown size={16} className={`text-gray-500 group-hover:text-white transition-transform ${isColorExpanded ? 'rotate-180' : ''}`} />
                    </div>
                    {isColorExpanded && (
                      <div className="flex flex-wrap gap-2">
                        {['All', 'black', 'white', 'gray', 'blue', 'red', 'green', 'gold'].map((color) => {
                          const isSelected = selectedColors.includes(color);
                          let colorClass = '';
                          if (color === 'black') colorClass = 'bg-black border border-gray-600';
                          else if (color === 'white') colorClass = 'bg-white border border-gray-400';
                          else if (color === 'gray') colorClass = 'bg-gray-400';
                          else if (color === 'blue') colorClass = 'bg-blue-600';
                          else if (color === 'red') colorClass = 'bg-red-600';
                          else if (color === 'green') colorClass = 'bg-green-600';
                          else if (color === 'gold') colorClass = 'bg-[#D4AF37]';
                          
                          return (
                            <button 
                              key={color}
                              onClick={() => handleFilterToggle(color, selectedColors, setSelectedColors)}
                              className={`flex items-center gap-1.5 px-3 py-1 border text-xs rounded-full transition-colors ${isSelected ? 'border-gray-500 text-white bg-gray-700' : 'border-gray-700 text-gray-300 hover:border-gray-500 hover:text-white bg-black/50'}`}
                            >
                              {color !== 'All' && <span className={`w-2.5 h-2.5 rounded-full ${colorClass}`}></span>}
                              {color}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  <button onClick={handleResetFilters} className="w-full bg-[#ed3237] hover:bg-[#d52b30] text-white py-3 rounded text-[13px] font-bold tracking-wider transition-colors shadow-lg">
                    Reset Filter
                  </button>
                </div>
              </div>

              {/* Main Content Area */}
              <div className="flex-1">
                <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2.5 sm:gap-6">
                  {productsList.filter(product => {
                    const matchesSearch = searchQuery === '' || product.name.toLowerCase().includes(searchQuery.toLowerCase());
                    const matchesCategory = selectedCategories.includes('All') || selectedCategories.some(c => product.category.toLowerCase().includes(c.toLowerCase()) || product.name.toLowerCase().includes(c.toLowerCase()));
                    const matchesPrice = product.price >= minPrice && product.price <= maxPrice;
                    
                    let matchesSize = true;
                    if (!selectedSizes.includes('All')) {
                      matchesSize = product.sizes ? product.sizes.some(s => selectedSizes.includes(s)) : false;
                    }
                    
                    let matchesColor = true;
                    if (!selectedColors.includes('All')) {
                      matchesColor = product.colors ? product.colors.some(c => selectedColors.map(sc => sc.toLowerCase()).includes(c.toLowerCase())) : false;
                    }

                    return matchesSearch && matchesCategory && matchesPrice && matchesSize && matchesColor;
                  }).map((product) => (
                    <div 
                      key={product.id} 
                      className="group bg-[#111] rounded-lg sm:rounded-xl overflow-hidden border border-gray-800 hover:shadow-2xl hover:border-gold transition-all duration-300 flex flex-col cursor-pointer"
                      onClick={() => handleProductClick(product)}
                    >
                      {/* Image Container */}
                      <div className="relative aspect-[3/4] overflow-hidden bg-gray-900">
                        {product.discountText && (
                          <div className="absolute top-2 left-2 sm:top-3 sm:left-3 z-20 bg-white text-black text-[9px] sm:text-[11px] font-bold px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-full shadow-md tracking-wide">
                            {product.discountText}
                          </div>
                        )}

                        <button
                          onClick={(e) => toggleWishlist(product.id, e)}
                          className="absolute top-2 right-2 sm:top-3 sm:right-3 z-20 bg-black/60 hover:bg-black/90 text-white p-1.5 sm:p-2 rounded-full backdrop-blur-md border border-gray-700/60 transition-all cursor-pointer group/heart"
                          title={wishlist.includes(product.id) ? "Remove from Wishlist" : "Add to Wishlist"}
                        >
                          <Heart 
                            size={14} 
                            className={`sm:w-4 sm:h-4 transition-all ${
                              wishlist.includes(product.id) 
                                ? "fill-red-500 text-red-500 scale-110" 
                                : "text-white group-hover/heart:text-red-400"
                            }`} 
                          />
                        </button>
                        
                        <img 
                          src={product.images[0]} 
                          alt={product.name} 
                          className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-110 opacity-90 group-hover:opacity-100"
                        />

                        {product.viewCount && (
                          <div className="absolute bottom-2 right-2 sm:bottom-3 sm:right-3 z-20 bg-black/70 text-white text-[9px] sm:text-xs px-1.5 sm:px-2 py-0.5 sm:py-1 flex items-center gap-1 rounded backdrop-blur-md border border-gray-700">
                            <Eye size={10} className="sm:w-3 sm:h-3" /> {product.viewCount}
                          </div>
                        )}
                      </div>
                      
                      {/* Product Details */}
                      <div className="p-2.5 sm:p-4 flex flex-col flex-grow">
                        <h4 className="text-xs sm:text-[15px] font-bold text-white mb-2 sm:mb-4 line-clamp-1 group-hover:text-gold transition-colors">{product.name}</h4>
                        
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-2.5 sm:mb-4 mt-auto">
                          <div className="flex items-center gap-1 sm:gap-2 flex-wrap">
                            <span className="text-xs sm:text-sm font-bold text-white">Tk {product.price.toLocaleString()}</span>
                            {product.originalPrice && (
                              <span className="text-[10px] sm:text-xs text-[#ed3237] line-through font-semibold">Tk {product.originalPrice.toLocaleString()}</span>
                            )}
                          </div>
                          {product.statusText && (
                            <span className="text-[9px] sm:text-[11px] font-bold text-[#ed3237] tracking-wider uppercase">{product.statusText}</span>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-1.5 sm:gap-2 mt-auto">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAddToCart(product, undefined, undefined, false);
                            }}
                            className="flex items-center justify-center gap-1 border border-gray-700 text-gray-300 py-1.5 sm:py-2 font-bold text-[9px] sm:text-[11px] hover:bg-gray-800 hover:text-white transition-all rounded cursor-pointer min-w-0"
                          >
                            <ShoppingBag size={12} className="shrink-0" />
                            <span className="truncate">Add</span>
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleBuyNow(product);
                            }}
                            className="flex items-center justify-center gap-1 bg-gold text-black py-1.5 sm:py-2 font-black text-[9px] sm:text-[11px] hover:bg-opacity-90 transition-all rounded cursor-pointer min-w-0"
                          >
                            <Zap size={12} className="shrink-0" />
                            <span className="truncate">Buy Now</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-12 text-center">
                    <button className="bg-[#ed3237] hover:bg-[#d52b30] text-white px-10 py-3 rounded font-bold tracking-wider text-sm shadow-lg transition-all transform hover:scale-105">
                      Load More Product
                    </button>
                </div>
              </div>
            </div>
          </div>
        )}
        {activeTab === 'Home' && (
          <>
            {/* Hero Section */}
            <div className="relative h-[80vh] w-full bg-gray-900 flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 z-0">
                <img 
                  src={socialLinks.heroBanner || "https://images.unsplash.com/photo-1617137968427-85924c800a22?q=80&w=1920&auto=format&fit=crop"}
                  alt="Stylish Male Model" 
                  className="w-full h-full object-cover opacity-60 object-top"
                />
              </div>
              
              <div className="relative z-10 text-center px-4 max-w-4xl mx-auto flex flex-col items-center">
                <span className="text-gold font-medium tracking-[0.2em] uppercase text-sm mb-4">Premium E-Commerce</span>
                <h2 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
                  Wear the<br />
                  <span className="italic font-light text-gold">Future.</span>
                </h2>
                <p className="text-gray-200 text-lg md:text-xl mb-10 max-w-2xl font-light">
                  Elevating men's fashion in Bangladesh with unmatched quality, exceptional tailoring, and a touch of gold.
                </p>
                <button 
                  onClick={() => handleNavigation('Our Products')}
                  className="gold-gradient text-white px-10 py-4 uppercase tracking-widest text-sm font-semibold transition-all hover:opacity-90 hover:scale-105 duration-300"
                >
                  Shop The Collection
                </button>
              </div>
            </div>

            {/* Featured Section */}
            <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-24">
              <div className="text-left mb-10 pl-2">
                <h3 className="text-3xl md:text-4xl text-white font-bold mb-2">Products Categories</h3>
                <p className="text-gray-400 font-medium tracking-wide">Popular Best Category Items</p>
              </div>

              {/* Category Grid */}
              <div 
                ref={sliderRef}
                className="flex overflow-x-auto gap-4 md:gap-6 pb-8 hide-scrollbar cursor-grab"
                onMouseDown={handleDragStart}
                onMouseMove={handleDragMove}
                onMouseUp={handleDragEnd}
                onMouseLeave={handleDragEnd}
                onTouchStart={handleDragStart}
                onTouchMove={handleDragMove}
                onTouchEnd={handleDragEnd}
              >
                {[...categoriesList, ...categoriesList, ...categoriesList].map((category, index) => (
                  <div 
                    key={`${category.id}-${index}`} 
                    className="min-w-[240px] w-[240px] md:min-w-[280px] md:w-[280px] aspect-[3/4] relative rounded-xl overflow-hidden cursor-pointer group shrink-0"
                    onClick={() => navigateToCategory(category.name)}
                  >
                    <img 
                      src={category.image} 
                      alt={category.name} 
                      draggable={false}
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                    />
                    {/* Shadow Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
                    
                    {/* Default Content */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-4 z-10 transition-opacity duration-300 group-hover:opacity-0">
                       <span className="text-white text-sm font-semibold tracking-widest mb-1 shadow-black drop-shadow-md">
                         Shop Now
                       </span>
                       <h4 className="text-2xl md:text-3xl font-bold text-white tracking-wider text-center drop-shadow-lg">
                         {category.name}
                       </h4>
                    </div>

                    {/* Hover Content */}
                    <div className="absolute inset-0 flex items-center justify-center z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <button className="bg-white text-black font-bold uppercase tracking-widest text-xs px-8 py-3 shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                        View All
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Most Popular Products Section */}
            <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-20 bg-black">
              <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-12 border-b border-gray-800 pb-6 gap-6">
                <div>
                  <h3 className="text-3xl md:text-4xl text-white font-bold mb-2">Most Popular Products</h3>
                  <p className="text-gray-400 font-medium tracking-wide uppercase text-sm">ALL PRODUCT</p>
                </div>
                
                {/* Filters */}
                <div className="flex flex-wrap gap-3">
                  {['ALL', 'New Arrival', 'Flash Sales', 'Upcoming'].map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setProductFilter(filter)}
                      className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                        productFilter === filter 
                          ? 'bg-gold text-black' 
                          : 'bg-black text-gray-400 border border-gray-700 hover:border-gold hover:text-white'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              {/* Product Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-8">
                {productsList.filter(p => productFilter === 'ALL' || (productFilter === 'New Arrival' && p.isNewArrival)).map((product) => (
                  <div 
                    key={product.id} 
                    className="group bg-[#111] rounded-lg sm:rounded-xl overflow-hidden border border-gray-800 hover:shadow-2xl hover:border-gold transition-all duration-300 flex flex-col cursor-pointer"
                    onClick={() => handleProductClick(product)}
                  >
                     {/* Image Container */}
                     <div className="relative aspect-[3/4] overflow-hidden bg-gray-900">
                       {product.discountText && (
                         <div className="absolute top-2 left-2 sm:top-3 sm:left-3 z-20 bg-gold text-black text-[9px] sm:text-xs font-bold px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-sm shadow-md">
                           {product.discountText}
                         </div>
                       )}

                       <button
                         onClick={(e) => toggleWishlist(product.id, e)}
                         className="absolute top-2 right-2 sm:top-3 sm:right-3 z-20 bg-black/60 hover:bg-black/90 text-white p-1.5 sm:p-2 rounded-full backdrop-blur-md border border-gray-700/60 transition-all cursor-pointer group/heart"
                         title={wishlist.includes(product.id) ? "Remove from Wishlist" : "Add to Wishlist"}
                       >
                         <Heart 
                           size={14} 
                           className={`sm:w-4 sm:h-4 transition-all ${
                             wishlist.includes(product.id) 
                               ? "fill-red-500 text-red-500 scale-110" 
                               : "text-white group-hover/heart:text-red-400"
                           }`} 
                         />
                       </button>
                       
                       <img 
                         src={product.images[0]} 
                         alt={product.name} 
                         className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105 opacity-90 group-hover:opacity-100"
                       />

                       {product.viewCount && (
                         <div className="absolute bottom-2 right-2 sm:bottom-3 sm:right-3 z-20 bg-black/70 text-white text-[9px] sm:text-xs px-1.5 sm:px-2 py-0.5 sm:py-1 flex items-center gap-1 rounded backdrop-blur-md border border-gray-700">
                           <Eye size={10} className="sm:w-3 sm:h-3" /> {product.viewCount}
                         </div>
                       )}
                     </div>
                     
                     {/* Product Details */}
                     <div className="p-2.5 sm:p-4 flex flex-col flex-grow">
                       <h4 className="text-xs sm:text-lg font-bold text-white mb-2 sm:mb-4 line-clamp-1 group-hover:text-gold transition-colors">{product.name}</h4>
                       
                       <div className="flex flex-wrap items-center justify-between gap-1 mb-2.5 sm:mb-4 mt-auto">
                         <div className="flex items-center gap-1 sm:gap-2 flex-wrap">
                           <span className="text-xs sm:text-sm font-semibold text-white">Tk {product.price.toLocaleString()}</span>
                           {product.originalPrice && (
                             <span className="text-[10px] sm:text-xs text-gray-500 line-through">Tk {product.originalPrice.toLocaleString()}</span>
                           )}
                         </div>
                         {product.statusText && (
                           <span className="text-[9px] sm:text-xs font-semibold text-red-500 uppercase tracking-wider">{product.statusText}</span>
                         )}
                       </div>

                       <div className="grid grid-cols-2 gap-1.5 sm:gap-2 mt-auto">
                         <button 
                           onClick={(e) => {
                             e.stopPropagation();
                             handleAddToCart(product, undefined, undefined, false);
                           }}
                           className="flex items-center justify-center gap-1 border border-gray-800 text-gray-300 py-1.5 sm:py-2 font-bold text-[9px] sm:text-[11px] hover:bg-gray-800 hover:text-white transition-all rounded-sm cursor-pointer min-w-0"
                         >
                           <ShoppingBag size={12} className="shrink-0" />
                           <span className="truncate">Add</span>
                         </button>
                         <button 
                           onClick={(e) => {
                             e.stopPropagation();
                             handleBuyNow(product);
                           }}
                           className="flex items-center justify-center gap-1 bg-gold text-black py-1.5 sm:py-2 font-black text-[9px] sm:text-[11px] hover:bg-opacity-90 transition-all rounded-sm cursor-pointer min-w-0"
                         >
                           <Zap size={12} className="shrink-0" />
                           <span className="truncate">Buy Now</span>
                         </button>
                       </div>
                     </div>
                  </div>
                ))}
              </div>

              <div className="mt-12 text-center">
                <button 
                  onClick={() => handleNavigation('Our Products')}
                  className="inline-flex items-center gap-3 bg-[#ed3237] hover:bg-[#d52b30] text-white px-10 py-3.5 rounded-sm font-bold uppercase tracking-wider text-[13px] shadow-lg transition-all transform hover:scale-105"
                >
                  <LayoutGrid size={18} /> More Product View
                </button>
              </div>
            </div>
            
            {/* Promo Banner */}
            <div className="w-full bg-[#111] py-20 px-4 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-gold blur-[100px] opacity-20 rounded-full"></div>
              <div className="max-w-4xl mx-auto text-center relative z-10">
                <h3 className="text-gold font-medium tracking-[0.2em] uppercase text-sm mb-4">Limited Time Offer</h3>
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Get 20% Off Your First Order</h2>
                <p className="text-gray-400 mb-8 font-light text-lg">Subscribe to our newsletter and receive exclusive updates, style tips, and early access to new collections.</p>
                <div className="flex flex-col sm:flex-row justify-center max-w-md mx-auto gap-4">
                  <input type="email" placeholder="Your Email Address" className="px-4 py-3 w-full bg-transparent border border-gray-600 text-white focus:outline-none focus:border-gold transition-colors" />
                  <button className="bg-white text-charcoal px-8 py-3 font-bold uppercase tracking-wider text-sm hover:bg-gold hover:text-white transition-colors whitespace-nowrap">
                    Subscribe
                  </button>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Contact Us Page */}
        {activeTab === 'Contact Us' && (
          <div className="bg-black min-h-screen py-16 px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16 animate-fade-in">
                <span className="text-gold font-semibold tracking-[0.2em] uppercase text-xs mb-3 block">Get in Touch</span>
                <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-wider mb-4">
                  WhatsApp <span className="text-gold">Support</span>
                </h2>
                <p className="text-gray-400 max-w-2xl mx-auto font-light leading-relaxed text-sm md:text-base">
                  Have any questions about Orvex products, sizing, stock availability, or orders? 
                  Click below to chat with our specialized support lines on WhatsApp. We are here to help you wear the future.
                </p>
              </div>

              {/* Grid of WhatsApp support departments */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
                {/* Support Agent 1 */}
                <a 
                  href="https://wa.me/8801889662914"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group bg-[#111] hover:bg-[#151515] border border-gray-800 hover:border-gold p-8 rounded-xl transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 blur-2xl rounded-full group-hover:bg-emerald-500/10 transition-all duration-300"></div>
                  <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mb-6 text-emerald-400 group-hover:scale-105 transition-transform duration-300 border border-emerald-500/20">
                    <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.18 1.448 4.615 1.449 5.43 0 9.851-4.382 9.853-9.764.001-2.607-1.015-5.059-2.861-6.905C16.388 2.08 13.937.1 11.39.1 5.96.1 1.539 4.482 1.537 9.863c0 1.554.433 3.076 1.252 4.418L1.844 21.05l6.98-1.812c-.068-.13-.136-.264-.202-.393zM15.8 12.603c-.224-.112-1.32-.65-1.523-.726-.203-.075-.35-.112-.497.112-.148.225-.57.712-.698.862-.128.15-.256.169-.48.056-.225-.112-.947-.35-1.804-1.115-.668-.596-1.118-1.332-1.25-1.557-.128-.225-.014-.346.1-.458.101-.1.224-.262.336-.393.112-.131.15-.224.224-.374.075-.15.038-.281-.019-.393-.056-.113-.497-1.2-.68-1.643-.18-.432-.361-.373-.496-.38-.128-.007-.275-.008-.423-.008-.148 0-.388.056-.59.274-.204.224-.778.761-.778 1.856s.794 2.152.905 2.302c.112.15 1.562 2.385 3.785 3.344.528.228.94.364 1.262.467.531.169 1.014.145 1.396.088.427-.064 1.32-.54 1.506-1.062.185-.523.185-.972.13-1.062-.056-.09-.204-.148-.428-.26z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-gold transition-colors font-sans">Masud Rana</h3>
                  <p className="text-xs text-gray-500 mb-5 font-semibold uppercase tracking-widest text-gold text-[#ed3237] font-mono">Assigned Agent</p>
                  
                  <div className="mt-auto w-full">
                    <span className="block text-xl font-bold text-white mb-1.5 font-mono tracking-wide">01889662914</span>
                    <span className="text-emerald-400 text-xs flex items-center justify-center gap-2 mb-6">
                      <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      Online • Tap to Chat
                    </span>
                    <span className="w-full inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-black py-3 rounded-md font-bold tracking-wider text-xs uppercase transition-colors shadow-md">
                      Chat Now
                    </span>
                  </div>
                </a>

                {/* Support Agent 2 */}
                <a 
                  href="https://wa.me/8801906139060"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group bg-[#111] hover:bg-[#151515] border border-gray-800 hover:border-gold p-8 rounded-xl transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 blur-2xl rounded-full group-hover:bg-emerald-500/10 transition-all duration-300"></div>
                  <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mb-6 text-emerald-400 group-hover:scale-105 transition-transform duration-300 border border-emerald-500/20">
                    <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.18 1.448 4.615 1.449 5.43 0 9.851-4.382 9.853-9.764.001-2.607-1.015-5.059-2.861-6.905C16.388 2.08 13.937.1 11.39.1 5.96.1 1.539 4.482 1.537 9.863c0 1.554.433 3.076 1.252 4.418L1.844 21.05l6.98-1.812c-.068-.13-.136-.264-.202-.393zM15.8 12.603c-.224-.112-1.32-.65-1.523-.726-.203-.075-.35-.112-.497.112-.148.225-.57.712-.698.862-.128.15-.256.169-.48.056-.225-.112-.947-.35-1.804-1.115-.668-.596-1.118-1.332-1.25-1.557-.128-.225-.014-.346.1-.458.101-.1.224-.262.336-.393.112-.131.15-.224.224-.374.075-.15.038-.281-.019-.393-.056-.113-.497-1.2-.68-1.643-.18-.432-.361-.373-.496-.38-.128-.007-.275-.008-.423-.008-.148 0-.388.056-.59.274-.204.224-.778.761-.778 1.856s.794 2.152.905 2.302c.112.15 1.562 2.385 3.785 3.344.528.228.94.364 1.262.467.531.169 1.014.145 1.396.088.427-.064 1.32-.54 1.506-1.062.185-.523.185-.972.13-1.062-.056-.09-.204-.148-.428-.26z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-gold transition-colors font-sans">Saiful Jaman</h3>
                  <p className="text-xs text-gray-500 mb-5 font-semibold uppercase tracking-widest text-[#ed3237] font-mono">Assigned Agent</p>
                  
                  <div className="mt-auto w-full">
                    <span className="block text-xl font-bold text-white mb-1.5 font-mono tracking-wide">01906139060</span>
                    <span className="text-emerald-400 text-xs flex items-center justify-center gap-2 mb-6">
                      <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      Online • Tap to Chat
                    </span>
                    <span className="w-full inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-black py-3 rounded-md font-bold tracking-wider text-xs uppercase transition-colors shadow-md">
                      Chat Now
                    </span>
                  </div>
                </a>

                {/* Support Agent 3 */}
                <a 
                  href="https://wa.me/8801816126195"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group bg-[#111] hover:bg-[#151515] border border-gray-800 hover:border-gold p-8 rounded-xl transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 blur-2xl rounded-full group-hover:bg-emerald-500/10 transition-all duration-300"></div>
                  <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mb-6 text-emerald-400 group-hover:scale-105 transition-transform duration-300 border border-emerald-500/20">
                    <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.18 1.448 4.615 1.449 5.43 0 9.851-4.382 9.853-9.764.001-2.607-1.015-5.059-2.861-6.905C16.388 2.08 13.937.1 11.39.1 5.96.1 1.539 4.482 1.537 9.863c0 1.554.433 3.076 1.252 4.418L1.844 21.05l6.98-1.812c-.068-.13-.136-.264-.202-.393zM15.8 12.603c-.224-.112-1.32-.65-1.523-.726-.203-.075-.35-.112-.497.112-.148.225-.57.712-.698.862-.128.15-.256.169-.48.056-.225-.112-.947-.35-1.804-1.115-.668-.596-1.118-1.332-1.25-1.557-.128-.225-.014-.346.1-.458.101-.1.224-.262.336-.393.112-.131.15-.224.224-.374.075-.15.038-.281-.019-.393-.056-.113-.497-1.2-.68-1.643-.18-.432-.361-.373-.496-.38-.128-.007-.275-.008-.423-.008-.148 0-.388.056-.59.274-.204.224-.778.761-.778 1.856s.794 2.152.905 2.302c.112.15 1.562 2.385 3.785 3.344.528.228.94.364 1.262.467.531.169 1.014.145 1.396.088.427-.064 1.32-.54 1.506-1.062.185-.523.185-.972.13-1.062-.056-.09-.204-.148-.428-.26z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-gold transition-colors font-sans">Eafin Hasan Siam</h3>
                  <p className="text-xs text-gray-500 mb-5 font-semibold uppercase tracking-widest text-[#ed3237] font-mono">Assigned Agent</p>
                  
                  <div className="mt-auto w-full">
                    <span className="block text-xl font-bold text-white mb-1.5 font-mono tracking-wide">01816126195</span>
                    <span className="text-emerald-400 text-xs flex items-center justify-center gap-2 mb-6">
                      <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      Online • Tap to Chat
                    </span>
                    <span className="w-full inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-black py-3 rounded-md font-bold tracking-wider text-xs uppercase transition-colors shadow-md">
                      Chat Now
                    </span>
                  </div>
                </a>
              </div>

              {/* Social Connections Showcase */}
              <div className="mb-16">
                <div className="text-center mb-10">
                  <span className="text-gold font-semibold tracking-[0.2em] uppercase text-xs mb-3 block">Follow Us</span>
                  <h3 className="text-2xl md:text-3xl font-black text-white uppercase tracking-wider">Connect & Follow</h3>
                  <p className="text-gray-400 text-xs md:text-sm font-light mt-2 max-w-lg mx-auto leading-relaxed">
                    Stay up-to-date with our latest collections, behind-the-scenes premium tailoring, and exclusive discounts via our social channels.
                  </p>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Instagram */}
                  <a 
                    href={socialLinks.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group bg-[#111] hover:bg-[#151515] border border-gray-800 hover:border-gold p-6 rounded-xl transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-16 h-16 bg-pink-500/5 blur-xl rounded-full group-hover:bg-pink-500/10 transition-all duration-300"></div>
                    <div className="w-12 h-12 bg-pink-500/10 rounded-full flex items-center justify-center mb-4 text-pink-400 group-hover:scale-110 transition-transform border border-pink-500/20">
                      <Instagram size={20} />
                    </div>
                    <span className="font-bold text-sm text-white group-hover:text-gold transition-colors">Instagram</span>
                    <span className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-mono">@_orvex__</span>
                  </a>

                  {/* Facebook */}
                  <a 
                    href={socialLinks.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group bg-[#111] hover:bg-[#151515] border border-gray-800 hover:border-gold p-6 rounded-xl transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-16 h-16 bg-blue-600/5 blur-xl rounded-full group-hover:bg-blue-600/10 transition-all duration-300"></div>
                    <div className="w-12 h-12 bg-blue-600/10 rounded-full flex items-center justify-center mb-4 text-blue-400 group-hover:scale-110 transition-transform border border-blue-600/20">
                      <Facebook size={20} />
                    </div>
                    <span className="font-bold text-sm text-white group-hover:text-gold transition-colors">Facebook Page</span>
                    <span className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-mono">/dapperoutfitsbd</span>
                  </a>

                  {/* WhatsApp */}
                  <a 
                    href={`https://wa.me/88${socialLinks.whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group bg-[#111] hover:bg-[#151515] border border-gray-800 hover:border-gold p-6 rounded-xl transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/5 blur-xl rounded-full group-hover:bg-emerald-500/10 transition-all duration-300"></div>
                    <div className="w-12 h-12 bg-emerald-500/10 rounded-full flex items-center justify-center mb-4 text-emerald-400 group-hover:scale-110 transition-transform border border-emerald-500/20">
                      <MessageSquare size={20} />
                    </div>
                    <span className="font-bold text-sm text-white group-hover:text-gold transition-colors">WhatsApp Care</span>
                    <span className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-mono">{socialLinks.whatsapp}</span>
                  </a>

                  {/* TikTok */}
                  <a 
                    href={socialLinks.tiktok}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group bg-[#111] hover:bg-[#151515] border border-gray-800 hover:border-gold p-6 rounded-xl transition-all duration-300 flex flex-col items-center text-center relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-16 h-16 bg-zinc-500/5 blur-xl rounded-full group-hover:bg-zinc-500/10 transition-all duration-300"></div>
                    <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mb-4 text-gray-300 group-hover:scale-110 transition-transform border border-white/10">
                      <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                        <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.02 1.63 4.15 1.12 1.15 2.67 1.83 4.25 1.95v3.91a8.55 8.55 0 0 1-5.18-1.74v7.91a8.04 8.04 0 0 1-8.15 8.04 8.04 8.04 0 0 1-8.03-8.23 8.04 8.04 0 0 1 8.24-7.85c.34.01.68.04 1.01.1v3.97a4.11 4.11 0 0 0-1.01-.13 4.14 4.14 0 0 0-4.14 4.14 4.14 4.14 0 0 0 4.14 4.15c2.28-.01 4.13-1.87 4.13-4.14V0h3.2z" />
                      </svg>
                    </div>
                    <span className="font-bold text-sm text-white group-hover:text-gold transition-colors">TikTok Creator</span>
                    <span className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-mono">@orvex___</span>
                  </a>
                </div>
              </div>

              {/* Physical details & map representation */}
              <div className="bg-[#111] border border-gray-800 rounded-xl p-8 md:p-12 flex flex-col md:flex-row gap-8 items-center justify-between">
                <div>
                  <h3 className="text-xl md:text-2xl font-black text-white mb-3 uppercase tracking-wider">Visit Orvex Headquarters</h3>
                  <p className="text-gray-400 text-sm font-light leading-relaxed max-w-lg mb-4">
                    Discover our tailoring house and flagship store. Experience our premium fabrics firsthand and consult with raw aesthetic stylists.
                  </p>
                  <p className="text-gray-300 text-sm flex items-center gap-2 font-medium">
                    <MapPin size={16} className="text-gold" /> Dhaka, Bangladesh
                  </p>
                </div>
                <div className="w-full md:w-auto shrink-0">
                  <a href="mailto:dapper.outfits12@gmail.com" className="w-full md:w-auto inline-flex items-center justify-center gap-3 border border-gray-700 hover:border-gold text-white py-4 px-8 font-bold tracking-widest text-xs uppercase transition-all rounded">
                    <Mail size={16} /> Email Us
                  </a>
                </div>
              </div>

              {/* Newsletter Signup Section */}
              <div className="mt-12 bg-gradient-to-r from-[#141414] via-[#1a1813] to-[#141414] border border-gold/20 rounded-xl p-8 md:p-12 relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 right-0 w-64 h-64 bg-gold/5 blur-3xl rounded-full pointer-events-none"></div>
                <div className="max-w-3xl mx-auto text-center relative z-10">
                  <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-gold/30 text-gold">
                    <Mail size={22} />
                  </div>
                  <span className="text-gold font-semibold tracking-[0.2em] uppercase text-xs mb-2 block">Exclusive Access</span>
                  <h3 className="text-2xl md:text-3xl font-black text-white uppercase tracking-wider mb-3">
                    Subscribe To <span className="text-gold">Orvex Insiders</span>
                  </h3>
                  <p className="text-gray-300 text-xs md:text-sm font-light max-w-xl mx-auto leading-relaxed mb-6">
                    Join our VIP list for secret sales, new arrival drops, and private marketing offers. Direct to your inbox.
                  </p>

                  {isNewsletterSubscribed ? (
                    <div className="bg-gold/10 border border-gold/40 rounded-lg p-5 flex items-center justify-center gap-3 text-gold max-w-md mx-auto animate-in fade-in zoom-in duration-300">
                      <CheckCircle2 size={22} className="shrink-0" />
                      <div className="text-left">
                        <h4 className="text-xs font-black uppercase tracking-wider">You're Subscribed!</h4>
                        <p className="text-[11px] text-gray-300">Thank you for joining Orvex Insiders. Stay tuned for special updates.</p>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleNewsletterSubmit} className="max-w-lg mx-auto">
                      <div className="flex flex-col sm:flex-row gap-2.5">
                        <div className="relative flex-1">
                          <input
                            type="email"
                            value={newsletterEmail}
                            onChange={(e) => {
                              setNewsletterEmail(e.target.value);
                              setNewsletterError('');
                            }}
                            placeholder="Enter your email address..."
                            className="w-full bg-black/80 border border-gray-800 focus:border-gold rounded py-3.5 px-4 text-xs text-white placeholder-gray-500 outline-none transition-all"
                          />
                        </div>
                        <button
                          type="submit"
                          className="bg-gold hover:bg-opacity-90 text-black py-3.5 px-8 rounded font-black text-xs uppercase tracking-widest transition-all cursor-pointer shadow-lg flex items-center justify-center gap-2 shrink-0 active:scale-[0.98]"
                        >
                          <span>Subscribe</span>
                          <Zap size={14} />
                        </button>
                      </div>
                      {newsletterError && (
                        <p className="text-red-400 text-[11px] font-semibold mt-2 text-left">{newsletterError}</p>
                      )}
                      <p className="text-[10px] text-gray-500 mt-3 font-light">
                        By subscribing, you agree to receive marketing communications from Orvex. Unsubscribe anytime.
                      </p>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* About Us Page */}
        {activeTab === 'About Us' && (
          <div className="bg-black min-h-screen py-16 px-4 animate-fade-in">
            <div className="max-w-4xl mx-auto text-left">
              <div className="text-center mb-16">
                <span className="text-gold font-semibold tracking-[0.2em] uppercase text-xs mb-3 block">Our Heritage</span>
                <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-wider mb-4">
                  About <span className="text-gold">Orvex</span>
                </h2>
                <div className="w-20 h-[1.5px] bg-gold mx-auto mb-6"></div>
                <p className="text-gray-400 max-w-2xl mx-auto font-light leading-relaxed text-sm md:text-base">
                  Redefining modern elegance, structured menswear, and high-style luxury.
                </p>
              </div>

              <div className="bg-[#111] border border-gray-800 rounded-xl p-8 md:p-12 mb-12 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 blur-3xl rounded-full"></div>
                <p className="text-gray-300 text-lg font-light leading-relaxed mb-6">
                  At <strong className="text-white font-bold font-mono">Orvex</strong>, we believe starting a garment is building a story. We curate, tailor, and craft state-of-the-art menswear designed with an eye for premium fabrics, sleek color accents, and structured fits.
                </p>
                <p className="text-gray-400 font-light leading-relaxed text-sm md:text-base">
                  Based in Dhaka, Bangladesh, we've partnered alongside world-class local artisans and tailored fits which confidently command attention in any setting. Every fiber, stitch, and selection represents a step towards absolute premium.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-[#111] border border-gray-800 rounded-xl p-6">
                  <h4 className="text-gold font-bold uppercase tracking-widest text-xs mb-3">Our Mission</h4>
                  <p className="text-gray-400 text-xs font-light leading-relaxed">To offer structured premium fashion solutions that eliminate style compromises for the modern gentleman.</p>
                </div>
                <div className="bg-[#111] border border-gray-800 rounded-xl p-6">
                  <h4 className="text-gold font-bold uppercase tracking-widest text-xs mb-3">Craftsmanship</h4>
                  <p className="text-gray-400 text-xs font-light leading-relaxed">Carefully sourced textiles paired with precise cutting specifications under continuous aesthetic controls.</p>
                </div>
                <div className="bg-[#111] border border-gray-800 rounded-xl p-6">
                  <h4 className="text-gold font-bold uppercase tracking-widest text-xs mb-3">Wear The Future</h4>
                  <p className="text-gray-400 text-xs font-light leading-relaxed">Timeless collections blended with futuristic silhouettes and rich, distinguished custom gold accents.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Categories Tab Page */}
        {activeTab === 'Categories' && (
          <div className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
            <div className="text-center mb-12">
              <span className="text-gold font-bold tracking-[0.25em] uppercase text-xs mb-3 block font-mono">Curated segments</span>
              <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-wider">
                Our <span className="text-gold">Collections</span>
              </h2>
              <div className="w-16 h-1 bg-gold mx-auto mt-4"></div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-8">
              {categoriesList.map(category => (
                <div 
                  key={category.id} 
                  onClick={() => navigateToCategory(category.name)}
                  className="relative h-60 sm:h-96 group rounded-xl overflow-hidden shadow-2xl cursor-pointer border border-gray-800 hover:border-gold transition-all duration-500 bg-[#111]"
                >
                  <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-all duration-300 z-10"></div>
                  <img src={category.image} alt={category.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-x-0 bottom-0 p-4 sm:p-8 z-20 bg-gradient-to-t from-black via-black/40 to-transparent">
                    <h3 className="font-extrabold text-base sm:text-2xl text-white tracking-wide uppercase">{category.name}</h3>
                    <p className="text-gold text-[10px] sm:text-xs uppercase font-mono tracking-wider mt-1 sm:mt-2 flex items-center gap-1.5 group-hover:translate-x-1.5 transition-transform duration-300">
                      View Segment &rarr;
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Fallback Placeholder for other tabs (Categories etc) */}
        {activeTab !== 'Home' && activeTab !== 'Our Products' && activeTab !== 'Contact Us' && activeTab !== 'About Us' && activeTab !== 'Categories' && (
          <div className="py-24 max-w-7xl mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold text-white mb-4">{activeTab}</h2>
            <p className="text-gray-400 mb-8">This page is under construction.</p>
            <button 
              onClick={() => handleNavigation('Home')}
              className="text-gold hover:underline underline-offset-4"
            >
              Return Home
            </button>
          </div>
        )}
        </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-charcoal text-white pt-20 pb-10 border-t-4 border-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-16">
            <div className="col-span-1 md:col-span-1">
              <h1 className="text-xl font-bold tracking-wider uppercase mb-6">
                Orvex
              </h1>
              <p className="text-gray-400 text-sm leading-relaxed font-light mb-6">
                Premium menswear brand based in Dhaka, Bangladesh. Curating the finest fabrics and tailored fits for the modern gentleman.
              </p>
              <button 
                onClick={() => setIsTrackOrderOpen(true)}
                className="bg-gold/10 hover:bg-gold/20 text-gold border border-gold/40 hover:border-gold rounded-lg px-4 py-2.5 text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-md group"
                title="Track existing order status"
              >
                <span className="w-2 h-2 rounded-full bg-gold animate-pulse"></span>
                <span>Track Your Order</span>
                <ChevronRight size={14} className="group-hover:translate-x-0.5 transition-transform text-gold" />
              </button>
            </div>
            
            <div>
              <h4 className="font-bold uppercase tracking-widest text-sm mb-6 text-gold">Shop</h4>
              <ul className="space-y-4 text-sm text-gray-400 font-light">
                <li><a href="#" className="hover:text-white transition-colors">New Arrivals</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Formal Wear</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Casual Wear</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Accessories</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold uppercase tracking-widest text-sm mb-6 text-gold">Support</h4>
              <ul className="space-y-4 text-sm text-gray-400 font-light">
                <li>
                  <button 
                    onClick={() => setIsTrackOrderOpen(true)} 
                    className="text-gold font-bold hover:text-white transition-colors cursor-pointer text-left flex items-center gap-1.5"
                  >
                    <span className="w-1.5 h-1.5 bg-gold rounded-full inline-block animate-pulse"></span>
                    Track Your Order
                  </button>
                </li>
                <li><button onClick={() => handleNavigation('Contact Us')} className="hover:text-white transition-colors cursor-pointer text-left">Contact Us</button></li>
                <li><a href="#" className="hover:text-white transition-colors">FAQs</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Shipping & Returns</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Size Guide</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold uppercase tracking-widest text-sm mb-6 text-gold">Connect</h4>
              <ul className="space-y-4 text-sm text-gray-400 font-light">
                <li><a href="https://www.instagram.com/_orvex__?igsh=MXA3ZWZ0NXczNzRnOA==" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Instagram</a></li>
                <li><a href="https://www.facebook.com/dapperoutfitsbd" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Facebook</a></li>
                <li><a href="https://wa.me/8801607369470" target="_blank" rel="noopener noreferrer" className="hover:text-gold text-emerald-400 transition-colors flex items-center gap-1">WhatsApp <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full inline-block animate-pulse"></span></a></li>
                <li><a href="https://www.tiktok.com/@orvex___?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">TikTok</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
            <p>&copy; {new Date().getFullYear()} Orvex. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <a href="#" className="hover:text-white">Privacy Policy</a>
              <a href="#" className="hover:text-white">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Support Widget */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end font-sans">
        {/* Chat Tooltip (visible when support list is closed) */}
        {!isSupportOpen && (
          <div className="bg-[#111] text-white text-xs border border-gray-800 px-4 py-2 rounded-lg shadow-2xl mb-3 mr-2 animate-bounce flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-semibold text-gray-200">Chat with us!</span>
          </div>
        )}

        {/* Support Options Popup card */}
        {isSupportOpen && (
          <div className="bg-[#111] text-white rounded-xl border border-gray-800 w-80 md:w-96 rounded-2xl shadow-2xl overflow-hidden mb-4 animate-fade-in-up">
            {/* Widget Header */}
            <div className="bg-[#121212] p-5 border-b border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-500/10 rounded-full flex items-center justify-center text-emerald-400 border border-emerald-500/20">
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.18 1.448 4.615 1.449 5.43 0 9.851-4.382 9.853-9.764.001-2.607-1.015-5.059-2.861-6.905C16.388 2.08 13.937.1 11.39.1 5.96.1 1.539 4.482 1.537 9.863c0 1.554.433 3.076 1.252 4.418L1.844 21.05l6.98-1.812c-.068-.13-.136-.264-.202-.393zM15.8 12.603c-.224-.112-1.32-.65-1.523-.726-.203-.075-.35-.112-.497.112-.148.225-.57.712-.698.862-.128.15-.256.169-.48.056-.225-.112-.947-.35-1.804-1.115-.668-.596-1.118-1.332-1.25-1.557-.128-.225-.014-.346.1-.458.101-.1.224-.262.336-.393.112-.131.15-.224.224-.374.075-.15.038-.281-.019-.393-.056-.113-.497-1.2-.68-1.643-.18-.432-.361-.373-.496-.38-.128-.007-.275-.008-.423-.008-.148 0-.388.056-.59.274-.204.224-.778.761-.778 1.856s.794 2.152.905 2.302c.112.15 1.562 2.385 3.785 3.344.528.228.94.364 1.262.467.531.169 1.014.145 1.396.088.427-.064 1.32-.54 1.506-1.062.185-.523.185-.972.13-1.062-.056-.09-.204-.148-.428-.26z" />
                  </svg>
                </div>
                <div className="text-left">
                  <h4 className="font-bold text-sm tracking-wide text-white uppercase">Orvex Care Hub</h4>
                  <p className="text-[11px] text-gray-500 font-light">Typically replies instantly</p>
                </div>
              </div>
              <button 
                onClick={() => setIsSupportOpen(false)} 
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Close Whatsapp support panel"
              >
                <X size={18} />
              </button>
            </div>

            {/* Widget Content - List of Active Channels */}
            <div className="p-4 bg-[#111] space-y-3.5">
              <p className="text-[11px] text-gray-400 font-light text-left px-1">
                Welcome! Choose one of our support lines to begin your chat on WhatsApp:
              </p>

              {supportStaff.map((staff) => (
                <a 
                  key={staff.id}
                  href={`https://wa.me/88${staff.phone}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 bg-black hover:bg-black/80 border border-gray-800 rounded-lg group transition-all duration-300"
                >
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-9 h-9 bg-emerald-500/10 rounded-full flex items-center justify-center text-emerald-400 border border-emerald-500/20 font-bold text-xs uppercase font-mono">
                      {staff.icon}
                    </div>
                    <div>
                      <h5 className="font-bold text-xs text-white group-hover:text-gold transition-colors">{staff.name}</h5>
                      <p className="text-[10px] text-gray-400 font-mono">{staff.phone}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className="text-[10px] text-emerald-400 font-medium tracking-wide flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      Online
                    </span>
                    <span className="text-[11px] font-bold text-gold group-hover:translate-x-1 transition-transform">
                      Chat &rarr;
                    </span>
                  </div>
                </a>
              ))}
            </div>

            {/* Support Footer banner */}
            <div className="bg-[#151515] px-4 py-3 border-t border-gray-800 text-center">
              <span className="text-[10px] text-gray-500 tracking-wider uppercase">Orvex Premium Menswear • Dhaka, BD</span>
            </div>
          </div>
        )}

        {/* Circular pulsing green trigger button */}
        <button 
          onClick={() => setIsSupportOpen(!isSupportOpen)}
          className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-2xl transition-all duration-300 relative group shrink-0 ${
            isSupportOpen ? 'bg-[#222] border border-gray-700 text-white' : 'bg-emerald-500 hover:bg-emerald-600 scale-105 active:scale-95'
          }`}
          aria-label="Contact support on WhatsApp"
        >
          {/* Pulsing ring indicator (only when closed) */}
          {!isSupportOpen && (
            <span className="absolute inset-0 rounded-full bg-emerald-400 opacity-20 group-hover:scale-125 transition-transform duration-500 animate-ping"></span>
          )}
          {isSupportOpen ? (
            <X size={24} />
          ) : (
            <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24">
              <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.767 5.766 0 1.253.398 2.413 1.077 3.367l-.707 2.585 2.653-.695c.829.479 1.785.753 2.806.753 3.181 0 5.767-2.586 5.767-5.766l-.062-.061c-3.064-3.057-5.748-5.949-5.767-5.949zM15.83 14.51c-.134-.146-.613-.393-.728-.432-.116-.039-.2-.058-.284.058s-.327.432-.401.51c-.074.078-.148.087-.282.02-.134-.067-.563-.207-1.072-.662-.396-.353-.663-.789-.741-.923-.078-.134-.008-.207.059-.273.061-.06.134-.156.2-.234.067-.078.089-.134.134-.224s.023-.169-.011-.235c-.034-.067-.284-.683-.389-.937-.102-.247-.206-.213-.284-.217l-.242-.005c-.084 0-.22.032-.336.158-.116.126-.443.433-.443 1.054s.452 1.22.515 1.305c.063.084.889 1.358 2.154 1.903.3.13.535.207.718.265.302.096.577.082.794.05.242-.036.728-.308.831-.605.103-.298.103-.553.072-.605a.258.258 0 0 0-.21-.122zM12 .003C5.372.003-.005 5.38-.005 12.008c0 2.115.549 4.102 1.517 5.839L.003 24l6.32-1.657a11.966 11.966 0 0 0 5.685 1.442c6.628 0 11.997-5.378 11.997-12.007S18.628.003 12 .002z" />
            </svg>
          )}
        </button>
      </div>

      {/* --- Shopping Cart Drawer --- */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden font-sans">
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm transition-opacity" onClick={() => setIsCartOpen(false)} />
          
          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-[#0b0b0b] border-l border-gray-800 text-white flex flex-col h-full shadow-2xl relative">
              
              {/* Header */}
              <div className="p-4 sm:p-6 border-b border-gray-800 flex justify-between items-center bg-[#111]">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="text-gold" size={20} />
                  <h3 className="font-extrabold uppercase tracking-wider text-xs">Shopping Bag ({cart.length})</h3>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      setIsCartOpen(false);
                      setIsTrackOrderOpen(true);
                    }}
                    className="bg-gold/10 hover:bg-gold/20 text-gold border border-gold/30 rounded px-2.5 py-1 text-[10px] sm:text-[11px] font-black uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
                    title="Track order status"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-gold animate-pulse"></span>
                    Track Order
                  </button>
                  <button onClick={() => { setIsCartOpen(false); setIsCheckoutOpen(false); }} className="text-gray-400 hover:text-white p-1 cursor-pointer">
                    <X size={20} />
                  </button>
                </div>
              </div>

              {/* Items List or Checkout Form */}
              <div className="flex-grow overflow-y-auto p-6 space-y-6">
                {isOrderSuccess ? (
                  /* --- Order Success Thank You Screen --- */
                  <div className="flex flex-col items-center justify-center text-center py-8 px-2 space-y-6 animate-in fade-in zoom-in duration-500 my-auto">
                    <div className="relative">
                      <div className="w-20 h-20 bg-gold/10 rounded-full flex items-center justify-center border-2 border-gold shadow-[0_0_35px_rgba(212,175,55,0.4)] animate-pulse">
                        <CheckCircle2 size={46} className="text-gold" />
                      </div>
                      <Zap size={20} className="text-gold absolute -top-1 -right-1 animate-bounce" />
                    </div>

                    <div className="space-y-3 max-w-sm">
                      <span className="inline-block bg-gold/10 text-gold text-[10px] sm:text-[11px] font-mono font-extrabold tracking-widest uppercase px-3 py-1 rounded-full border border-gold/30">
                        Order Placed Successfully
                      </span>
                      <h2 className="text-2xl sm:text-3xl font-black text-white leading-snug tracking-tight">
                        Thank you so much for shopping with <span className="text-gold">ORVEX</span>!
                      </h2>
                      <p className="text-xs sm:text-sm text-gray-300 font-medium leading-relaxed">
                        We have received your order and are processing it with care.
                      </p>
                    </div>

                    <div className="w-full bg-[#111] p-4 rounded-xl border border-gray-800 text-left space-y-2.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400">Payment Option:</span>
                        <span className="text-gold font-bold">Cash On Delivery (COD)</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400">Destination:</span>
                        <span className="text-white font-bold">{checkoutDistrict || 'Dhaka'}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400">Auto Redirecting:</span>
                        <span className="text-gold font-bold">Home Page</span>
                      </div>
                    </div>

                    {/* Redirect countdown visual */}
                    <div className="w-full space-y-2 pt-2">
                      <p className="text-[11px] text-gray-400 font-mono flex items-center justify-center gap-2">
                        <Loader2 size={13} className="animate-spin text-gold" />
                        Redirecting to Home in 3 seconds...
                      </p>
                      <div className="w-full bg-gray-850 h-1.5 rounded-full overflow-hidden border border-gray-800">
                        <div className="bg-gradient-to-r from-yellow-600 via-gold to-yellow-400 h-full rounded-full animate-pulse w-full"></div>
                      </div>
                    </div>
                  </div>
                ) : cart.length === 0 ? (
                  <div className="text-center py-20">
                    <ShoppingCart size={48} className="text-gray-700 mx-auto mb-4" />
                    <p className="text-xs text-gray-400 font-light uppercase tracking-widest">Your shopping bag is empty</p>
                    <button onClick={() => setIsCartOpen(false)} className="mt-4 text-xs font-bold text-gold hover:underline bg-transparent border-0 cursor-pointer">
                      Continue Exploring &rarr;
                    </button>
                  </div>
                ) : isCheckoutOpen ? (
                  /* --- Checkout View Form --- */
                  <form className="space-y-4 text-left" onSubmit={(e) => {
                    e.preventDefault();
                    if (!checkoutName || !checkoutPhone || !checkoutAddress || !checkoutDistrict || isPlacingOrder || isOrderSuccess) return;
                    
                    setIsPlacingOrder(true);

                    setTimeout(() => {
                      const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
                      const shippingCost = shippingMethod === 'inside' ? 80 : 150;
                      const grandTotal = subtotal + shippingCost;

                      const newOrder = {
                        id: Date.now().toString(),
                        customerName: checkoutName,
                        customerPhone: checkoutPhone,
                        customerAltPhone: checkoutAltPhone || undefined,
                        customerAddress: checkoutAddress,
                        customerDistrict: checkoutDistrict,
                        customerDivision: checkoutDivision,
                        deliveryNotes: checkoutInstruction || undefined,
                        shippingCost: shippingCost,
                        items: cart.map(item => ({
                          productId: item.id,
                          productName: item.name,
                          price: item.price,
                          quantity: item.quantity,
                          size: item.selectedSize || 'One Size',
                          color: item.selectedColor || 'Standard',
                          image: item.images[0]
                        })),
                        totalAmount: grandTotal,
                        status: 'Pending' as const,
                        date: new Date().toLocaleString()
                      };

                      handleUpdateOrders([newOrder, ...orders]);
                      handleUpdateCart([]);
                      
                      // Automatically log in customer on successful order placement
                      setCustomerPhone(checkoutPhone);
                      setCustomerName(checkoutName);
                      localStorage.setItem('orvex_customer_phone', checkoutPhone);
                      localStorage.setItem('orvex_customer_name', checkoutName);

                      // Send to WhatsApp
                      const messageText = `*New Order - Orvex*
*Customer Details:*
Name: ${checkoutName}
Phone: ${checkoutPhone}
${checkoutAltPhone ? `Alt Phone: ${checkoutAltPhone}\n` : ''}Address: ${checkoutAddress}, ${checkoutDistrict}, ${checkoutDivision}
${checkoutInstruction ? `Notes: ${checkoutInstruction}\n` : ''}
*Order Items:*
${cart.map(item => `- ${item.name} (x${item.quantity}) - Size: ${item.selectedSize}, Color: ${item.selectedColor} - Tk ${item.price * item.quantity}`).join('\n')}

*Summary:*
Subtotal: Tk ${subtotal}
Shipping: Tk ${shippingCost}
*Grand Total: Tk ${grandTotal}*`;

                      const whatsappUrl = `https://wa.me/8801607369470?text=${encodeURIComponent(messageText)}`;
                      window.open(whatsappUrl, '_blank');

                      setIsPlacingOrder(false);
                      setIsOrderSuccess(true);

                      // Wait 3 seconds with Thank You screen then redirect to Home Page
                      setTimeout(() => {
                        setIsOrderSuccess(false);
                        
                        setCheckoutName('');
                        setCheckoutPhone('');
                        setCheckoutAltPhone('');
                        setCheckoutAddress('');
                        setCheckoutDistrict('');
                        setCheckoutDivision('Dhaka');
                        setCheckoutInstruction('');
                        
                        setIsCheckoutOpen(false);
                        setIsCartOpen(false);
                        
                        handleNavigation('Home');
                      }, 3000);
                    }, 1000);
                  }}>
                    <h4 className="text-xs font-black uppercase text-gold tracking-widest mb-3 pb-1 border-b border-gray-800">Delivery Information (Cash On Delivery)</h4>
                    
                    {/* Address profile selection */}
                    <div className="mb-4 bg-black/40 p-3 rounded-lg border border-gray-850">
                      <div className="flex justify-between items-center mb-2">
                        <span className="block text-[10px] text-gray-400 uppercase tracking-wider font-mono">My Delivery Addresses</span>
                        <span className="text-[9px] text-gold font-mono bg-gold/10 px-1.5 py-0.5 rounded">Address Book</span>
                      </div>
                      
                      <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1 mb-2">
                        {savedAddresses.map((addr) => (
                          <div 
                            key={addr.id}
                            onClick={() => handleSelectAddress(addr.id)}
                            className={`p-2 rounded-lg border text-left cursor-pointer transition-all ${
                              selectedAddressId === addr.id
                                ? 'bg-gold/10 border-gold shadow-md'
                                : 'bg-black/60 border-gray-800 hover:border-gray-700'
                            }`}
                          >
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-[11px] text-white flex items-center gap-1">
                                <MapPin size={10} className="text-gold" /> {addr.alias}
                              </span>
                              {selectedAddressId === addr.id && <Check size={11} className="text-gold" />}
                            </div>
                            <p className="text-[10px] text-gray-300 mt-1 truncate">{addr.name} • {addr.phone}</p>
                            <p className="text-[10px] text-gray-500 truncate">{addr.address}, {addr.district}</p>
                          </div>
                        ))}
                      </div>

                      {!isAddingNewAddress ? (
                        <button
                          type="button"
                          onClick={() => {
                            setIsAddingNewAddress(true);
                            setSelectedAddressId('');
                          }}
                          className="w-full bg-black/40 hover:bg-black/80 border border-dashed border-gray-800 hover:border-gold py-2 rounded text-[10px] font-bold text-gold uppercase tracking-wider transition-all cursor-pointer"
                        >
                          + Add New Address
                        </button>
                      ) : (
                        <div className="border border-gray-800 bg-black/90 rounded-lg p-3 space-y-3 mt-2 text-left">
                          <div className="flex justify-between items-center border-b border-gray-850 pb-1.5">
                            <span className="text-[9px] text-gold uppercase tracking-wider font-mono font-bold">Add Address Profile</span>
                            <button 
                              type="button" 
                              onClick={() => setIsAddingNewAddress(false)}
                              className="text-gray-400 hover:text-white text-[10px] uppercase font-mono bg-transparent border-0 cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                          <div>
                            <label className="block text-[9px] text-gray-500 uppercase tracking-wider font-mono">Profile Title (e.g. Home, Office, Work)</label>
                            <input 
                              type="text"
                              required
                              placeholder="e.g. Home, Office"
                              value={newAddressAlias}
                              onChange={e => setNewAddressAlias(e.target.value)}
                              className="w-full bg-black border border-gray-850 rounded p-1.5 text-xs text-white focus:outline-none focus:border-gold mt-1"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] text-gray-500 uppercase tracking-wider font-mono">Full Name</label>
                              <input 
                                type="text"
                                required
                                placeholder="Receiver Name"
                                value={newAddressName}
                                onChange={e => setNewAddressName(e.target.value)}
                                className="w-full bg-black border border-gray-850 rounded p-1.5 text-xs text-white focus:outline-none"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] text-gray-500 uppercase tracking-wider font-mono">Mobile Number</label>
                              <input 
                                type="text"
                                required
                                placeholder="017xxxxxxx"
                                value={newAddressPhone}
                                onChange={e => setNewAddressPhone(e.target.value)}
                                className="w-full bg-black border border-gray-850 rounded p-1.5 text-xs text-white focus:outline-none font-mono"
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-[9px] text-gray-500 uppercase tracking-wider font-mono">Alternative Phone (Optional)</label>
                            <input 
                              type="text"
                              placeholder="Alternative number"
                              value={newAddressAltPhone}
                              onChange={e => setNewAddressAltPhone(e.target.value)}
                              className="w-full bg-black border border-gray-850 rounded p-1.5 text-xs text-white focus:outline-none font-mono"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] text-gray-500 uppercase tracking-wider font-mono">Division</label>
                              <select
                                value={newAddressDivision}
                                onChange={e => {
                                  const div = e.target.value;
                                  setNewAddressDivision(div);
                                  const districts = BANGLADESH_DIVISIONS[div]?.districts || [];
                                  if (districts.length > 0) {
                                    setNewAddressDistrict(districts[0].en);
                                  }
                                }}
                                className="w-full bg-black border border-gray-850 rounded p-1.5 text-xs text-white focus:outline-none cursor-pointer"
                              >
                                {Object.keys(BANGLADESH_DIVISIONS).map(div => (
                                  <option key={div} value={div}>{div}</option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <label className="block text-[9px] text-gray-500 uppercase tracking-wider font-mono">District / Area</label>
                              <select
                                value={newAddressDistrict}
                                onChange={e => {
                                  const distName = e.target.value;
                                  setNewAddressDistrict(distName);
                                  const found = ALL_BANGLADESH_DISTRICTS.find(d => d.en === distName);
                                  if (found) {
                                    setNewAddressDivision(found.division);
                                  }
                                }}
                                className="w-full bg-black border border-gray-850 rounded p-1.5 text-xs text-white focus:outline-none cursor-pointer"
                              >
                                {ALL_BANGLADESH_DISTRICTS.map(dist => (
                                  <option key={dist.en} value={dist.en}>{dist.en}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                          <div>
                            <label className="block text-[9px] text-gray-500 uppercase tracking-wider font-mono">Detailed Delivery Address</label>
                            <textarea 
                              required
                              rows={2}
                              placeholder="e.g. House 14, Road 5"
                              value={newAddressDetail}
                              onChange={e => setNewAddressDetail(e.target.value)}
                              className="w-full bg-black border border-gray-850 rounded p-1.5 text-xs text-white focus:outline-none"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={handleAddNewAddress}
                            className="w-full bg-gold hover:bg-opacity-90 text-black py-2 rounded text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer"
                          >
                            Save & Set Active Profile
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Active Form Inputs */}
                    <div className="space-y-3.5 border-t border-gray-850 pt-3">
                      <div>
                        <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-mono">1. Customer Name *</label>
                        <input 
                          type="text" 
                          value={checkoutName}
                          onChange={e => setCheckoutName(e.target.value)}
                          required
                          placeholder="e.g., Masud Rana"
                          className="w-full bg-black border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2.5">
                        <div>
                          <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-mono">2. Mobile Number *</label>
                          <input 
                            type="text" 
                            value={checkoutPhone}
                            onChange={e => setCheckoutPhone(e.target.value)}
                            required
                            placeholder="e.g. 017xxxxxxxx"
                            className="w-full bg-black border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-mono">Alternative Phone (Optional)</label>
                          <input 
                            type="text" 
                            value={checkoutAltPhone}
                            onChange={e => setCheckoutAltPhone(e.target.value)}
                            placeholder="Alternative mobile"
                            className="w-full bg-black border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors font-mono"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2.5">
                        <div>
                          <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-mono">3. Division *</label>
                          <select 
                            value={checkoutDivision}
                            onChange={e => {
                              const division = e.target.value;
                              setCheckoutDivision(division);
                              const districts = BANGLADESH_DIVISIONS[division]?.districts || [];
                              const firstDist = districts[0]?.en || '';
                              setCheckoutDistrict(firstDist);
                              
                              if (firstDist === 'Gazipur') {
                                setShippingMethod('inside');
                              } else {
                                setShippingMethod('outside');
                              }
                            }}
                            className="w-full bg-black border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors cursor-pointer"
                          >
                            {Object.keys(BANGLADESH_DIVISIONS).map(div => (
                              <option key={div} value={div} className="bg-black text-white">{div}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-mono">4. District *</label>
                          <select 
                            value={checkoutDistrict}
                            onChange={e => {
                              const dist = e.target.value;
                              setCheckoutDistrict(dist);
                              const found = ALL_BANGLADESH_DISTRICTS.find(d => d.en === dist);
                              if (found) {
                                setCheckoutDivision(found.division);
                              }
                              if (dist === 'Gazipur') {
                                setShippingMethod('inside');
                              } else {
                                setShippingMethod('outside');
                              }
                            }}
                            className="w-full bg-black border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors cursor-pointer font-sans"
                          >
                            {ALL_BANGLADESH_DISTRICTS.map(dist => (
                              <option key={dist.en} value={dist.en} className="bg-black text-white">{dist.en}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-mono">5. Full Address *</label>
                        <textarea 
                          value={checkoutAddress}
                          onChange={e => setCheckoutAddress(e.target.value)}
                          required
                          rows={2}
                          placeholder="e.g. Village/Road/Holding, Thana, Post Office"
                          className="w-full bg-black border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-gray-400 tracking-wider mb-1 font-mono">SPECIAL INSTRUCTIONS</label>
                        <input 
                          type="text" 
                          value={checkoutInstruction}
                          onChange={e => setCheckoutInstruction(e.target.value)}
                          placeholder="e.g. call before delivery, deliver inside gate"
                          className="w-full bg-black border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors"
                        />
                      </div>

                      {/* Explicit Shipping Cost selector */}
                      <div>
                        <span className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1.5 font-mono">Shipping Zone Charge</span>
                        <div className="grid grid-cols-2 gap-2">
                          <button 
                            type="button"
                            onClick={() => setShippingMethod('inside')}
                            className={`p-2 rounded border text-center transition-all cursor-pointer ${
                              shippingMethod === 'inside' 
                                ? 'bg-gold/10 border-gold text-gold font-bold' 
                                : 'bg-black border-gray-850 text-gray-400 hover:border-gray-700'
                            }`}
                          >
                            <span className="text-[10px] block font-mono">Inside Gazipur</span>
                            <span className="text-xs font-bold font-mono text-gold mt-1 block">Tk 80</span>
                          </button>
                          <button 
                            type="button"
                            onClick={() => setShippingMethod('outside')}
                            className={`p-2 rounded border text-center transition-all cursor-pointer ${
                              shippingMethod === 'outside' 
                                ? 'bg-gold/10 border-gold text-gold font-bold' 
                                : 'bg-black border-gray-850 text-gray-400 hover:border-gray-700'
                            }`}
                          >
                            <span className="text-[10px] block font-mono">Outside Gazipur</span>
                            <span className="text-xs font-bold font-mono text-gold mt-1 block">Tk 150</span>
                          </button>
                        </div>
                      </div>

                      {/* Live billing summary review block */}
                      <div className="bg-[#111] p-3 rounded-lg border border-gray-850 space-y-2 mt-4 text-[11px] font-mono">
                        <h5 className="text-[10px] text-gold font-black uppercase text-center border-b border-gray-800 pb-1.5 mb-1 tracking-wider">Checkout Order Summary</h5>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Subtotal Amount:</span>
                          <span className="text-white">Tk {cart.reduce((sum, item) => sum + (item.price * item.quantity), 0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Shipping Delivery Fee:</span>
                          <span className="text-white">Tk {shippingMethod === 'inside' ? 80 : 150}</span>
                        </div>
                        <div className="flex justify-between border-t border-gray-800 pt-1.5 font-bold text-xs">
                          <span className="text-gold uppercase tracking-wider font-black">Grand Total Payable:</span>
                          <span className="text-gold font-black">Tk {cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) + (shippingMethod === 'inside' ? 80 : 150)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded text-[10px] text-amber-500 leading-relaxed font-light">
                      <strong>Standard Cash On Delivery Terms:</strong> Open parcel checks are allowed. Delivery charges apply on delivery doorstep.
                    </div>

                    <div className="pt-4 flex gap-3">
                      <button 
                        type="button" 
                        onClick={() => setIsCheckoutOpen(false)}
                        disabled={isPlacingOrder || isOrderSuccess}
                        className="flex-1 bg-transparent hover:bg-white/5 border border-gray-800 py-3 text-xs font-bold uppercase tracking-wider rounded transition-all cursor-pointer disabled:opacity-50"
                      >
                        Back To Bag
                      </button>
                      <button 
                        type="submit" 
                        disabled={isPlacingOrder || isOrderSuccess}
                        className={`flex-1 py-3.5 text-xs font-black uppercase tracking-wider rounded transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg ${
                          isOrderSuccess 
                            ? 'bg-emerald-500 text-white shadow-emerald-500/20 scale-[1.02]' 
                            : isPlacingOrder 
                            ? 'bg-gold/80 text-black cursor-not-allowed' 
                            : 'bg-gold hover:bg-opacity-95 text-black'
                        }`}
                      >
                        {isOrderSuccess ? (
                          <span className="flex items-center gap-2 text-white font-bold animate-in fade-in zoom-in duration-300">
                            <CheckCircle2 size={18} className="text-white animate-bounce" />
                            Order Placed!
                          </span>
                        ) : isPlacingOrder ? (
                          <span className="flex items-center gap-2 text-black font-bold">
                            <Loader2 size={18} className="animate-spin text-black" />
                            Processing...
                          </span>
                        ) : (
                          <span className="flex items-center gap-2">
                            <Zap size={16} /> Place Order COD
                          </span>
                        )}
                      </button>
                    </div>
                  </form>
                ) : (
                  /* --- Items List View --- */
                  <div className="space-y-4">
                    {cart.map((item, idx) => (
                      <div key={idx} className="flex gap-4 p-3 bg-black/60 rounded border border-gray-850 items-center font-sans">
                        <img src={item.images[0]} alt={item.name} className="w-12 h-18 object-cover rounded border border-gray-800 bg-gray-900 shrink-0" />
                        <div className="flex-grow text-left">
                          <h4 className="font-bold text-xs text-white uppercase line-clamp-1">{item.name}</h4>
                          
                          {/* Sizing & Color inline dropdown modification in Cart Item */}
                          <div className="flex flex-wrap gap-x-2.5 gap-y-1 mt-1">
                            {(() => {
                              const isPant = item.name.toLowerCase().includes('pant') || 
                                             item.name.toLowerCase().includes('chino') || 
                                             item.name.toLowerCase().includes('cargo') || 
                                             item.name.toLowerCase().includes('jean') || 
                                             item.name.toLowerCase().includes('trouser');
                              
                              const sizesList = isPant 
                                ? ['28', '29', '30', '31', '32', '33', '34', '35'] 
                                : (item.sizes && item.sizes.length > 0 && !item.sizes.includes('One Size') 
                                    ? item.sizes 
                                    : ['S', 'M', 'L', 'XL', '28', '29', '30', '31', '32', '33', '34', '35']);

                              return (
                                <div className="flex items-center gap-1 bg-[#111] border border-gray-800 p-0.5 px-1.5 rounded">
                                  <span className="text-[9px] text-gray-500 uppercase tracking-widest font-mono">Size:</span>
                                  <select 
                                    value={item.selectedSize}
                                    onChange={(e) => {
                                      const updated = cart.map((c, i) => i === idx ? { ...c, selectedSize: e.target.value } : c);
                                      handleUpdateCart(updated);
                                    }}
                                    className="bg-transparent text-[10px] text-gold focus:outline-none font-bold font-mono border-0 p-0 cursor-pointer"
                                  >
                                    {sizesList.map(sz => (
                                      <option key={sz} value={sz} className="bg-black text-white">{sz}</option>
                                    ))}
                                  </select>
                                </div>
                              );
                            })()}

                            {item.colors && item.colors.length > 0 && (
                              <div className="flex items-center gap-1 bg-[#111] border border-gray-800 p-0.5 px-1.5 rounded">
                                <span className="text-[9px] text-gray-500 uppercase tracking-widest font-mono">Color:</span>
                                <select 
                                  value={item.selectedColor}
                                  onChange={(e) => {
                                    const updated = cart.map((c, i) => i === idx ? { ...c, selectedColor: e.target.value } : c);
                                    handleUpdateCart(updated);
                                  }}
                                  className="bg-transparent text-[10px] text-white focus:outline-none font-bold font-mono border-0 p-0 cursor-pointer"
                                >
                                  {item.colors.map(col => (
                                    <option key={col} value={col} className="bg-black text-white">{col}</option>
                                  ))}
                                </select>
                              </div>
                            )}
                          </div>

                          <div className="text-xs text-gold font-mono font-semibold mt-2.5">Tk {item.price}</div>
                          
                          {/* Qty and Trash */}
                          <div className="flex justify-between items-center mt-2.5">
                            <div className="flex items-center border border-gray-800 rounded overflow-hidden bg-black">
                              <button 
                                onClick={() => {
                                  const updated = item.quantity > 1 
                                    ? cart.map((c, i) => i === idx ? { ...c, quantity: c.quantity - 1 } : c)
                                    : cart.filter((c, i) => i !== idx);
                                  handleUpdateCart(updated);
                                }}
                                className="px-2 py-0.5 bg-[#111] hover:bg-white/5 text-[10px] font-bold text-gray-400 border-0 cursor-pointer"
                              >
                                -
                              </button>
                              <span className="px-2.5 text-xs font-bold text-white font-mono bg-black">{item.quantity}</span>
                              <button 
                                onClick={() => {
                                  const updated = cart.map((c, i) => i === idx ? { ...c, quantity: c.quantity + 1 } : c);
                                  handleUpdateCart(updated);
                                }}
                                className="px-2 py-0.5 bg-[#111] hover:bg-white/5 text-[10px] font-bold text-gray-400 border-0 cursor-pointer"
                              >
                                +
                              </button>
                            </div>
                            <button 
                              onClick={() => {
                                handleUpdateCart(cart.filter((c, i) => i !== idx));
                              }}
                              className="text-gray-500 hover:text-red-500 p-1 bg-transparent border-0 cursor-pointer"
                              title="Remove"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Drawer Footer Summary */}
              {cart.length > 0 && !isCheckoutOpen && (
                <div className="p-6 border-t border-gray-800 bg-[#111] space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs uppercase tracking-widest text-gray-400 font-mono">Consolidated Subtotal</span>
                    <span className="text-lg font-black font-mono text-white">Tk {cart.reduce((sum, item) => sum + (item.price * item.quantity), 0)}</span>
                  </div>
                  <p className="text-[10px] text-gray-500 leading-normal text-left font-light">
                    Local Vat & standard BD shipping courier charges will be assessed at delivery doorstep.
                  </p>
                  <button 
                    onClick={() => setIsCheckoutOpen(true)}
                    className="w-full bg-gold hover:bg-opacity-95 text-black py-3.5 rounded font-black text-xs uppercase tracking-widest transition-all shadow-xl cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Zap size={16} /> Buy Now / Checkout
                  </button>
                </div>
              )}

            </div>
          </div>
        </div>
      )}

      {/* --- Wishlist Drawer --- */}
      {isWishlistOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden font-sans">
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm transition-opacity" onClick={() => setIsWishlistOpen(false)} />
          
          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-[#0b0b0b] border-l border-gray-800 text-white flex flex-col h-full shadow-2xl relative">
              
              {/* Header */}
              <div className="p-4 sm:p-6 border-b border-gray-800 flex justify-between items-center bg-[#111]">
                <div className="flex items-center gap-2">
                  <Heart className="text-red-500 fill-red-500" size={20} />
                  <h3 className="font-extrabold uppercase tracking-wider text-xs">My Wishlist ({wishlist.length})</h3>
                </div>
                <button onClick={() => setIsWishlistOpen(false)} className="text-gray-400 hover:text-white p-1 cursor-pointer">
                  <X size={20} />
                </button>
              </div>

              {/* Items List */}
              <div className="flex-grow overflow-y-auto p-4 sm:p-6 space-y-4">
                {wishlist.length === 0 ? (
                  <div className="text-center py-20 flex flex-col items-center">
                    <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-4 text-red-500">
                      <Heart size={32} />
                    </div>
                    <p className="text-sm text-gray-300 font-bold mb-1">Your wishlist is empty</p>
                    <p className="text-xs text-gray-500 font-light max-w-xs mb-6">Explore our collection and click the heart icon on any product to save your favorites!</p>
                    <button
                      onClick={() => {
                        setIsWishlistOpen(false);
                        handleNavigation('Our Products');
                      }}
                      className="bg-gold hover:bg-opacity-90 text-black px-6 py-2.5 rounded font-black text-xs uppercase tracking-wider transition-all cursor-pointer"
                    >
                      Explore Products
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {productsList.filter(p => wishlist.includes(p.id)).map(product => (
                      <div key={product.id} className="flex gap-3 bg-[#111] p-3 rounded-lg border border-gray-800 hover:border-gray-700 transition-all group relative items-center">
                        <img 
                          src={product.images[0]} 
                          alt={product.name} 
                          className="w-16 h-20 object-cover rounded bg-gray-900 shrink-0 cursor-pointer border border-gray-800" 
                          onClick={() => {
                            setSelectedProduct(product);
                            setIsWishlistOpen(false);
                          }}
                        />
                        <div className="flex flex-col flex-grow justify-between py-0.5 min-w-0">
                          <div>
                            <h4 
                              className="text-xs sm:text-sm font-bold text-white truncate cursor-pointer hover:text-gold transition-colors"
                              onClick={() => {
                                setSelectedProduct(product);
                                setIsWishlistOpen(false);
                              }}
                            >
                              {product.name}
                            </h4>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs text-gold font-bold">Tk {product.price.toLocaleString()}</span>
                              {product.originalPrice && (
                                <span className="text-[10px] text-gray-500 line-through">Tk {product.originalPrice.toLocaleString()}</span>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-2 mt-3">
                            <button
                              onClick={() => {
                                handleAddToCart(product, undefined, undefined, true);
                                toggleWishlist(product.id);
                              }}
                              className="flex-1 bg-gold hover:bg-opacity-90 text-black py-1.5 px-3 rounded font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer min-w-0"
                            >
                              <ShoppingBag size={12} className="shrink-0" />
                              <span className="truncate">Move To Bag</span>
                            </button>
                            <button
                              onClick={() => toggleWishlist(product.id)}
                              className="p-1.5 bg-gray-800/80 hover:bg-red-500/20 text-gray-400 hover:text-red-500 rounded border border-gray-700 transition-all cursor-pointer"
                              title="Remove item"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Footer */}
              {wishlist.length > 0 && (
                <div className="p-4 sm:p-6 border-t border-gray-800 bg-[#111] space-y-2.5">
                  <button
                    onClick={() => {
                      productsList.filter(p => wishlist.includes(p.id)).forEach(p => {
                        handleAddToCart(p, undefined, undefined, false);
                      });
                      setIsWishlistOpen(false);
                      setIsCartOpen(true);
                    }}
                    className="w-full bg-gold hover:bg-opacity-90 text-black py-3 rounded font-black uppercase tracking-wider text-xs shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <ShoppingBag size={15} /> Move All To Shopping Bag
                  </button>
                  <button
                    onClick={() => {
                      setWishlist([]);
                      localStorage.setItem('orvex_wishlist', JSON.stringify([]));
                    }}
                    className="w-full bg-transparent hover:bg-white/5 text-gray-400 hover:text-red-400 py-2 text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer"
                  >
                    Clear Wishlist
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- Authentication & Customer Orders Modal --- */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 font-sans">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-md transition-opacity" onClick={() => setIsAuthModalOpen(false)} />
          
          <div className={`bg-[#111] border border-gray-800/80 rounded-2xl p-5 md:p-7 w-full relative z-10 shadow-2xl transition-all duration-300 max-h-[85vh] flex flex-col ${
            authView === 'customer' && customerPhone ? 'max-w-2xl' : 'max-w-md'
          }`}>
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-red-600 via-gold to-yellow-500"></div>
            
            {/* Close */}
            <button 
              onClick={() => setIsAuthModalOpen(false)} 
              className="absolute top-4 right-4 text-gray-500 hover:text-white bg-transparent border-0 cursor-pointer p-1 rounded-full hover:bg-white/5 transition-colors"
            >
              <X size={18} />
            </button>

            {/* Custom Modal Content Wrapper */}
            <div className="overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-gray-800 flex-grow">
              
              {authView === 'customer' ? (
                /* ================= CUSTOMER PORTAL & ORDERS SCREEN ================= */
                customerPhone ? (
                  /* --- Logged In Customer Orders Panel --- */
                  <div className="space-y-5 py-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-850 pb-4">
                      <div>
                        <span className="text-[10px] text-gold uppercase tracking-[0.25em] font-bold font-mono">Assalamu Alaikum</span>
                        <h3 className="text-lg md:text-xl font-black text-white hover:text-gold transition-colors">{customerName || 'Dapper Gentleman'}</h3>
                        <p className="text-[11px] text-gray-400 font-mono flex items-center gap-1 mt-0.5">
                          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                          Phone: <strong className="text-white">{customerPhone}</strong>
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          setCustomerPhone('');
                          setCustomerName('');
                          localStorage.removeItem('orvex_customer_phone');
                          localStorage.removeItem('orvex_customer_name');
                        }}
                        className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider transition-all self-start sm:self-center cursor-pointer flex items-center gap-1"
                      >
                        ✕ Logout
                      </button>
                    </div>

                    <div>
                      <h4 className="text-xs uppercase font-mono tracking-widest text-gray-400 font-bold mb-3 flex items-center gap-1.5">
                        <ShoppingBag size={13} className="text-gold" /> My Orders History
                      </h4>

                      {/* past order query using existing orders list */}
                      {(() => {
                        const trimmedPhone = customerPhone.trim();
                        const customerOrders = orders.filter(o => 
                          o.customerPhone.trim() === trimmedPhone || 
                          (o.customerAltPhone && o.customerAltPhone.trim() === trimmedPhone)
                        );

                        if (customerOrders.length === 0) {
                          return (
                            <div className="bg-black/60 border border-gray-850/60 rounded-xl p-8 text-center space-y-3.5">
                              <div className="w-11 h-11 rounded-full bg-gold/10 text-gold flex items-center justify-center mx-auto">
                                <ShoppingBag size={18} />
                              </div>
                              <div className="space-y-1">
                                <p className="text-xs font-black text-white uppercase tracking-wider">No Past Bookings</p>
                                <p className="text-[10px] text-gray-400 max-w-sm mx-auto leading-relaxed">
                                  We couldn't detect any active or prior bookings placed with phone <strong className="text-gold font-mono">{customerPhone}</strong>. Complete an order to explore dapper premium collections!
                                </p>
                              </div>
                            </div>
                          );
                        }

                        return (
                          <div className="space-y-4">
                            {customerOrders.map((order) => {
                              const statuses = ['Pending', 'Approved', 'Shipped', 'Delivered'];
                              const currentIdx = statuses.indexOf(order.status);
                              const isCancelled = order.status === 'Cancelled';

                              return (
                                <div key={order.id} className="bg-black/50 border border-gray-850/70 rounded-xl p-4 space-y-4 text-left font-sans">
                                  {/* Order top bar */}
                                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-gray-900 pb-2.5">
                                    <div>
                                      <div className="flex items-center gap-1.5 flex-wrap">
                                        <span className="text-[12px] font-black font-mono text-white tracking-widest uppercase">{order.id}</span>
                                        <span className={`text-[8px] font-mono font-black uppercase px-1.5 py-0.5 rounded border ${
                                          order.status === 'Pending' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                                          order.status === 'Approved' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' :
                                          order.status === 'Shipped' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                                          order.status === 'Delivered' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                                          'bg-red-500/10 text-red-400 border-red-500/20'
                                        }`}>
                                          {order.status === 'Approved' ? 'Confirmed' : order.status}
                                        </span>
                                      </div>
                                      <span className="text-[9px] text-gray-500 font-mono block mt-0.5">Order Date: {order.date || 'Standard'}</span>
                                    </div>
                                    
                                    <div className="text-left sm:text-right shrink-0">
                                      <span className="block text-[8px] text-gray-500 uppercase tracking-widest font-mono">Invoice Amount</span>
                                      <span className="text-[13px] font-black font-mono text-gold">Tk {order.totalAmount}</span>
                                    </div>
                                  </div>

                                  {/* Receiver Preview */}
                                  <div className="text-[10px] leading-relaxed text-gray-400 bg-black/30 p-2 rounded border border-gray-900/40">
                                    <span className="text-[9px] text-gray-500 font-mono font-bold block uppercase mb-0.5">Shipping Address</span>
                                    <strong className="text-white font-sans">{order.customerName}</strong> &bull; {order.customerAddress}, {order.customerDistrict || ''}
                                  </div>

                                  {/* Outer item list */}
                                  <div className="space-y-2 pt-1">
                                    <span className="text-[9px] text-gray-500 font-mono font-bold block uppercase tracking-wider">Outfits Details</span>
                                    {order.items.map((it, iIdx) => (
                                      <div key={iIdx} className="flex gap-2.5 justify-between items-center bg-[#151515] p-1.5 rounded border border-gray-900">
                                        <div className="flex gap-2 items-center min-w-0">
                                          <img src={it.image} alt={it.productName} className="w-8 h-10 object-cover rounded bg-gray-900 border border-gray-850 shrink-0" />
                                          <div className="min-w-0">
                                            <h5 className="font-bold text-white text-[11px] truncate uppercase">{it.productName}</h5>
                                            <div className="flex gap-2 text-[8px] font-mono text-gray-400 mt-0.5">
                                              <span>Size: <strong className="text-white font-sans">{it.size || 'Standard'}</strong></span>
                                              <span>Qty: <strong className="text-white">{it.quantity}</strong></span>
                                            </div>
                                          </div>
                                        </div>
                                        <span className="text-[11px] font-mono text-gold shrink-0">Tk {it.price * it.quantity}</span>
                                      </div>
                                    ))}
                                  </div>

                                  {/* Inline Tracker Timeline */}
                                  {!isCancelled ? (
                                    <div className="py-2 bg-black/40 rounded-lg p-2.5 border border-gray-900/50">
                                      <div className="relative flex justify-between items-center max-w-sm mx-auto">
                                        <div className="absolute top-2 left-0 right-0 h-0.5 bg-gray-850 -z-10" />
                                        <div 
                                          className="absolute top-2 left-0 h-0.5 bg-gold transition-all duration-300 -z-10" 
                                          style={{ width: `${currentIdx >= 0 ? (currentIdx / 3) * 100 : 0}%` }}
                                        />

                                        {statuses.map((st, sIdx) => {
                                          const isPassed = currentIdx >= sIdx;
                                          const isCurrent = currentIdx === sIdx;
                                          const lab = st === 'Pending' ? 'Pending' : st === 'Approved' ? 'Confirmed' : st === 'Shipped' ? 'Shipped' : 'Delivered';

                                          return (
                                            <div key={st} className="flex flex-col items-center">
                                              <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[7px] font-bold border transition-all ${
                                                isPassed ? 'bg-gold border-gold text-black shadow-sm' : 'bg-[#111] border-gray-800 text-gray-500'
                                              } ${isCurrent ? 'ring-1 ring-gold/40 ring-offset-1 ring-offset-black scale-110' : ''}`}>
                                                ✓
                                              </div>
                                              <span className={`text-[7px] font-mono mt-1 font-bold tracking-tight uppercase ${isPassed ? 'text-gold' : 'text-gray-500'}`}>{lab}</span>
                                            </div>
                                          );
                                        })}
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="bg-red-500/5 p-2 rounded border border-red-500/10 text-center">
                                      <span className="text-[8px] bg-red-500 text-white font-mono font-bold px-1.5 py-0.2 rounded uppercase">Cancelled</span>
                                      <p className="text-[10px] text-red-400 mt-1">This order has been cancelled by Orvex support.</p>
                                    </div>
                                  )}

                                  {/* Quick contact panel */}
                                  <div className="flex gap-2 text-[10px] pt-1">
                                    <a
                                      href={`https://wa.me/8801534001923?text=${encodeURIComponent(`Assalamu Alaikum support. I want to inquire about my Order ${order.id}. Registered Phone: ${order.customerPhone}.`)}`}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="flex-1 bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/20 text-[#25D366] py-1.5 rounded font-bold text-center uppercase tracking-wider flex items-center justify-center gap-1 transition-all"
                                    >
                                      WhatsApp Inquiry
                                    </a>
                                    <a
                                      href="tel:01534001923"
                                      className="flex-1 bg-gold/5 hover:bg-gold/10 border border-gold/20 text-gold py-1.5 rounded font-bold text-center uppercase tracking-wider flex items-center justify-center gap-1 transition-all"
                                    >
                                      Phone Hotline
                                    </a>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                ) : (
                  /* --- Logged Out Customer Login Inputs --- */
                  <div className="space-y-4 py-2 text-left font-sans">
                    <div className="text-center mb-5">
                      <span className="text-[9px] text-gold uppercase tracking-[0.25em] font-bold font-mono">Dapper Outfit Hub</span>
                      <h3 className="text-lg md:text-xl font-black text-white uppercase tracking-wider mt-1">Customer Portal</h3>
                      <p className="text-[11px] text-gray-400 mt-1">Enter your mobile phone number to log in and inspect your cash-on-delivery orders history instantly.</p>
                    </div>

                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        const p = customerPhoneInput.trim();
                        if (p.length < 11) {
                          setCustomerLoginError('Please enter a valid 11-digit mobile number.');
                          return;
                        }
                        const n = customerNameInput.trim() || 'Dapper Gentleman';
                        setCustomerPhone(p);
                        setCustomerName(n);
                        localStorage.setItem('orvex_customer_phone', p);
                        localStorage.setItem('orvex_customer_name', n);
                        setCustomerLoginError('');
                      }} 
                      className="space-y-3.5"
                    >
                      <div>
                        <label className="block text-[9px] text-gray-400 uppercase font-mono mb-1 font-bold">Mobile Phone Number *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. 017xxxxxxxx"
                          value={customerPhoneInput}
                          onChange={e => setCustomerPhoneInput(e.target.value.replace(/[^0-9]/g, ''))}
                          className="w-full bg-black border border-gray-800 focus:border-gold rounded-lg px-3 py-2 text-xs text-white focus:outline-none transition-colors font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-[9px] text-gray-400 uppercase font-mono mb-1 font-bold">Your Name - Optional</label>
                        <input
                          type="text"
                          placeholder="Enter your name"
                          value={customerNameInput}
                          onChange={e => setCustomerNameInput(e.target.value)}
                          className="w-full bg-black border border-gray-800 focus:border-gold rounded-lg px-3 py-2 text-xs text-white focus:outline-none transition-colors"
                        />
                      </div>

                      {customerLoginError && (
                        <p className="text-red-500 text-[10px] font-mono">{customerLoginError}</p>
                      )}

                      <button
                        type="submit"
                        className="w-full bg-gold hover:bg-opacity-95 text-black font-extrabold uppercase text-xs py-2.5 rounded-lg tracking-wider transition-all shadow-md mt-2 cursor-pointer"
                      >
                        Sign In & View Orders &rarr;
                      </button>
                    </form>
                  </div>
                )
              ) : (
                /* ================= ADMIN AUTH ENTRANCE SCREEN ================= */
                <div className="py-2 text-left space-y-4 font-sans">
                  <div className="text-center mb-4">
                    <span className="text-[9px] text-gold uppercase tracking-[0.25em] font-bold font-mono">ORVEX SECURE ENTRANCE</span>
                    <h3 className="text-lg md:text-xl font-black text-white uppercase tracking-wider mt-1">Admin Portal Access</h3>
                  </div>

                  {/* Access Guide Notes */}
                  <div className="bg-black/85 border border-gray-800 p-3.5 rounded-lg text-xs leading-normal">
                    <div className="flex items-center gap-1.5 text-gold font-bold text-[10px] uppercase font-mono tracking-wider">
                      <Lock size={12} className="shrink-0" /> Registered Container Credentials
                    </div>
                    <p className="text-gray-400 text-[11px] font-sans">
                      This cockpit provides total control over products catalog and customer cash-on-delivery orders. Use details below to initiate admin control session:
                    </p>
                    <div className="grid grid-cols-1 pt-1.5 text-[11px] font-mono gap-1 text-gray-300 bg-black/40 p-2 rounded border border-gray-900 mt-1">
                      <div><span className="text-gray-500">Email:</span> <span className="text-white font-bold select-all">dapper.outfits12@gmail.com</span></div>
                      <div><span className="text-gray-500">Pass:</span> <span className="text-white font-bold select-all">dapper123</span></div>
                    </div>
                  </div>

                  <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase font-mono tracking-wider mb-1 font-bold">Email Address</label>
                      <input 
                        type="email" 
                        value={authEmail}
                        onChange={e => setAuthEmail(e.target.value)}
                        required
                        placeholder="dapper.outfits12@gmail.com"
                        className="w-full bg-black border border-gray-800 focus:border-gold rounded-lg px-3 py-2 text-xs text-white focus:outline-none transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase font-mono tracking-wider mb-1 font-bold">Password</label>
                      <input 
                        type="password" 
                        value={authPassword}
                        onChange={e => setAuthPassword(e.target.value)}
                        required
                        placeholder="Enter admin password"
                        className="w-full bg-black border border-gray-850 focus:border-gold rounded-lg px-3 py-2 text-xs text-white focus:outline-none transition-colors selection:bg-gold"
                      />
                    </div>

                    {authError && (
                      <div className="flex items-center gap-1.5 text-red-500 text-[11px] pt-1">
                        <AlertCircle size={12} className="shrink-0" />
                        <span>{authError}</span>
                      </div>
                    )}

                    <div className="pt-1">
                      <button 
                        type="submit" 
                        className="w-full bg-gold hover:bg-opacity-95 text-black font-extrabold uppercase text-xs py-2.5 rounded-lg tracking-wider transition-all shadow-lg cursor-pointer animate-pulse"
                      >
                        Initiate Control Session &rarr;
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Toggle switch between customer & admin view */}
              <div className="border-t border-gray-850 mt-5 pt-4 text-center">
                {authView === 'customer' ? (
                  <button
                    onClick={() => {
                      setAuthView('admin');
                      setCustomerLoginError('');
                    }}
                    className="text-[10px] text-gray-500 hover:text-gold transition-colors underline uppercase tracking-wider font-mono bg-transparent border-0 cursor-pointer"
                  >
                    🔐 Store Operator? Click for Admin Entrance
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setAuthView('customer');
                      setAuthError('');
                    }}
                    className="text-[10px] text-gray-500 hover:text-gold transition-colors underline uppercase tracking-wider font-mono bg-transparent border-0 cursor-pointer"
                  >
                    👤 Return to Customer Orders Console
                  </button>
                )}
              </div>

            </div>
          </div>
        </div>
      )}

      {/* --- Track Order Drawer / Overlay --- */}
      {isTrackOrderOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 font-sans">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-md transition-opacity" onClick={() => setIsTrackOrderOpen(false)} />
          
          <div className="bg-[#111] border border-gray-850/90 rounded-2xl p-5 md:p-7 max-w-2xl w-full relative z-10 shadow-2xl overflow-y-auto max-h-[90vh] md:max-h-[85vh] scrollbar-thin scrollbar-thumb-gray-800">
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-gold via-red-600 to-amber-500"></div>
            
            {/* Close */}
            <button onClick={() => setIsTrackOrderOpen(false)} className="absolute top-5 right-5 text-gray-400 hover:text-white bg-transparent border-0 cursor-pointer text-sm">
              ✕
            </button>

            <div className="text-center mb-6">
              <div className="inline-flex items-center gap-1.5 bg-gold/10 text-gold px-2.5 py-0.5 rounded text-[10px] font-black uppercase tracking-widest font-mono">
                <MapPin size={11} className="animate-bounce text-gold" /> Orvex Track Console
              </div>
              <h3 className="text-xl md:text-2xl font-black text-white uppercase tracking-wider mt-1.5">Track Your Order</h3>
              <p className="text-[11px] md:text-xs text-gray-400 mt-1">Enter your Mobile Number or Order ID to inspect cash-on-delivery progress instantly.</p>
            </div>

            {/* Tracker Search Input */}
            <div className="bg-black/60 p-4 rounded-xl border border-gray-850 mb-6 font-sans">
              <label className="block text-[10px] text-gray-500 uppercase tracking-widest font-mono font-bold mb-1.5">Mobile Number or Order ID</label>
              <div className="flex gap-2">
                <div className="relative flex-grow">
                  <input
                    type="text"
                    placeholder="e.g. 017xxxxxxxx or ORV-XXXX"
                    value={trackSearchQuery}
                    onChange={(e) => {
                      const val = e.target.value;
                      setTrackSearchQuery(val);
                      localStorage.setItem('orvex_last_track_query', val);
                    }}
                    className="w-full bg-black border border-gray-800 focus:border-gold rounded-lg pl-9 pr-3 py-2.5 text-sm text-white focus:outline-none transition-colors font-mono tracking-wide"
                  />
                  <Search size={15} className="absolute left-3 top-3.5 text-gray-500" />
                </div>
                {trackSearchQuery && (
                  <button 
                    onClick={() => {
                      setTrackSearchQuery('');
                      localStorage.removeItem('orvex_last_track_query');
                    }}
                    className="bg-gray-900 border border-gray-800 text-gray-400 hover:text-white text-xs px-3 rounded-lg"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* Helpful Tips */}
              <div className="flex gap-2 items-start mt-3 text-[10px] text-gray-500 leading-normal">
                <span className="text-gold font-bold">★ Tip:</span>
                <span>Type the phone number used while placing the order to see all your historical dapper purchases instantly!</span>
              </div>
            </div>

            {/* Filter Status Quick Tabs */}
            {orders.length > 0 && (
              <div className="flex flex-wrap gap-1.5 justify-center py-2.5 border-y border-gray-850/60 bg-black/25 rounded-xl p-3 mb-5">
                {([
                  { key: 'All', labelEn: 'All', color: 'border-gold text-gold bg-gold/5' },
                  { key: 'Pending', labelEn: 'Pending', color: 'border-amber-500 text-amber-500 bg-amber-500/5' },
                  { key: 'Approved', labelEn: 'Confirmed', color: 'border-blue-400 text-blue-400 bg-blue-400/5' },
                  { key: 'Shipped', labelEn: 'Shipped', color: 'border-purple-400 text-purple-400 bg-purple-400/5' },
                  { key: 'Delivered', labelEn: 'Delivered', color: 'border-emerald-400 text-emerald-400 bg-emerald-400/5' },
                  { key: 'Cancelled', labelEn: 'Cancelled', color: 'border-red-500 text-red-500 bg-red-500/5' }
                ] as const).map(tab => {
                  const queryResult = trackSearchQuery.trim() ? searchedOrders : orders;
                  const count = tab.key === 'All' 
                    ? queryResult.length 
                    : queryResult.filter(o => o.status === tab.key).length;
                  const isActive = trackActiveTab === tab.key;
                  
                  return (
                    <button
                      key={tab.key}
                      onClick={() => setTrackActiveTab(tab.key)}
                      className={`px-2.5 py-1.5 rounded-lg border text-[10px] font-black uppercase transition-all tracking-wider cursor-pointer flex items-center gap-1 ${
                        isActive 
                          ? `${tab.color} border-current shadow-md scale-102` 
                          : 'border-gray-850 text-gray-400 hover:text-white hover:border-gray-700 bg-transparent'
                      }`}
                    >
                      <span>{tab.labelEn}</span>
                      <span className={`px-1 rounded text-[9px] font-mono font-bold ${
                        isActive ? 'bg-white/10 text-current' : 'bg-gray-900 border border-gray-850 text-gray-400'
                      }`}>
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Search Results Block */}
            <div className="space-y-6">
              {orders.length === 0 ? (
                /* No Orders Created At All on This Browser */
                <div className="bg-black/60 rounded-xl border border-gray-850 p-8 text-center space-y-4 font-sans">
                  <div className="w-12 h-12 rounded-full bg-gold/10 text-gold border border-gold/20 flex items-center justify-center mx-auto text-xl font-mono font-black shrink-0">
                    ℹ
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-white uppercase tracking-wider">No Orders Placed Yet</h4>
                    <p className="text-[11px] text-gray-400 max-w-sm mx-auto leading-relaxed">
                      You haven't placed any premium bespoke outfit orders on this browser yet! 
                      Browse our high-contrast luxury apparel catalogs to book your look today.
                    </p>
                  </div>
                  <div className="pt-2">
                    <button 
                      onClick={() => setIsTrackOrderOpen(false)}
                      className="bg-gold hover:bg-yellow-500 text-black px-5 py-2.5 rounded-lg text-xs font-black uppercase tracking-wider font-sans transition-all cursor-pointer inline-flex items-center gap-2"
                    >
                      Browse Best Sellers
                    </button>
                  </div>
                </div>
              ) : (
                /* If they have orders, compute filtered view and render */
                (() => {
                  const queryResult = trackSearchQuery.trim() ? searchedOrders : orders;
                  const finalFilteredOrders = queryResult.filter(order => {
                    if (trackActiveTab === 'All') return true;
                    return order.status === trackActiveTab;
                  });

                  // If they searched but no overall matches
                  if (trackSearchQuery.trim() && queryResult.length === 0) {
                    return (
                      <div className="bg-black/60 rounded-xl border border-gray-850 p-8 text-center space-y-4 font-sans">
                        <div className="w-12 h-12 rounded-full bg-red-600/10 text-red-500 border border-red-500/20 flex items-center justify-center mx-auto text-xl font-mono font-black shrink-0">
                          !
                        </div>
                        <div className="space-y-1">
                          <h4 className="text-sm font-bold text-white uppercase tracking-wider">No Orders Found</h4>
                          <p className="text-[11px] text-gray-400 max-w-sm mx-auto leading-relaxed">
                            We could not find any active booking with query "<span className="text-gold font-bold">{trackSearchQuery}</span>". Ensure style matches of your 11-digit mobile number or ID!
                          </p>
                        </div>
                        <div className="pt-2">
                          <p className="text-[10px] text-gray-500 leading-normal">
                            Need assistance? Phone call our helpline dial immediately: <br />
                            <strong className="text-white text-xs select-all font-mono">01534001923</strong>
                          </p>
                        </div>
                      </div>
                    );
                  }

                  // If they filtered down but no matches in this specific tab
                  if (finalFilteredOrders.length === 0) {
                    return (
                      <div className="bg-[#141414] rounded-xl border border-gray-850 p-8 text-center space-y-3 font-sans">
                        <div className="w-10 h-10 rounded-full bg-gray-900 text-gray-400 border border-gray-850 flex items-center justify-center mx-auto text-sm shrink-0">
                          ∅
                        </div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">No {trackActiveTab} Orders Found</h4>
                        <p className="text-[10px] text-gray-500 max-w-xs mx-auto leading-normal">
                          There are currently no orders in status <strong>{trackActiveTab === 'Approved' ? 'Confirmed' : trackActiveTab}</strong> inside this list. Check other status categories above!
                        </p>
                      </div>
                    );
                  }

                  return finalFilteredOrders.map((order) => {
                    // Decide matching timeline status progression
                    const statuses = ['Pending', 'Approved', 'Shipped', 'Delivered'];
                    const currentIdx = statuses.indexOf(order.status);
                    const isCancelled = order.status === 'Cancelled';

                    return (
                      <div key={order.id} className="bg-black/45 rounded-xl border border-gray-850/65 hover:border-gray-800 transition-colors p-4 md:p-5 space-y-5 text-left font-sans">
                        {/* Order Meta */}
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-850 pb-3 gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-black font-mono text-white tracking-widest">{order.id}</span>
                              <span className={`text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded border ${
                                order.status === 'Pending' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                                order.status === 'Approved' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' :
                                order.status === 'Shipped' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                                order.status === 'Delivered' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                                'bg-red-500/10 text-red-400 border-red-500/20'
                              }`}>
                                {order.status === 'Approved' ? 'Confirmed' : order.status}
                              </span>
                            </div>
                            <span className="text-[9px] text-gray-500 font-mono">Date: {new Date(order.date || Date.now()).toLocaleDateString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}</span>
                          </div>
                          
                          <div className="text-left sm:text-right font-mono">
                            <span className="block text-[8px] text-gray-500 uppercase tracking-widest font-sans text-left sm:text-right">Grand Total</span>
                            <span className="text-xs md:text-sm font-black text-gold">Tk {order.totalAmount}</span>
                          </div>
                        </div>

                        {/* Visual Status Tracker Progress Indicator Bar */}
                        {!isCancelled ? (
                          <div className="py-1">
                            <div className="relative flex justify-between items-center max-w-md mx-auto">
                              {/* Connector Lines */}
                              <div className="absolute top-3 left-0 right-0 h-0.5 bg-gray-800 -z-10" />
                              <div 
                                className="absolute top-3 left-0 h-0.5 bg-gold transition-all duration-500 -z-10" 
                                style={{ width: `${currentIdx >= 0 ? (currentIdx / 3) * 100 : 0}%` }}
                              />

                              {statuses.map((st, sIdx) => {
                                const resolvedEng = st === 'Pending' ? 'Pending' : st === 'Approved' ? 'Confirmed' : st === 'Shipped' ? 'Shipped' : 'Delivered';
                                const isPassed = currentIdx >= sIdx;
                                const isCurrent = currentIdx === sIdx;

                                return (
                                  <div key={st} className="flex flex-col items-center">
                                    <div className={`w-6.5 h-6.5 rounded-full flex items-center justify-center text-[9px] font-black border transition-all ${
                                      isPassed 
                                        ? 'bg-gold border-gold text-black shadow-md shadow-gold/20 font-black' 
                                        : 'bg-[#111] border-gray-800 text-gray-500 font-medium'
                                    } ${isCurrent ? 'ring-2 ring-gold/40 ring-offset-2 ring-offset-black scale-110' : ''}`}>
                                      {sIdx + 1}
                                    </div>
                                    <span className={`text-[8px] font-black tracking-wide mt-1 uppercase ${isPassed ? 'text-gold' : 'text-gray-500'}`}>{resolvedEng}</span>
                                  </div>
                                );
                              })}
                            </div>

                            {/* Tracking Detail State Text Description */}
                            <div className="mt-4 p-2.5 rounded-lg bg-[#141414] border border-gray-850/60 text-center text-[11px] leading-relaxed max-w-sm mx-auto font-sans">
                              {order.status === 'Pending' && (
                                <p className="text-amber-500">
                                  <strong>Status: Pending</strong> — We have received your booking! Our customer support agent will call you shortly to approve shipping.
                                </p>
                              )}
                              {order.status === 'Approved' && (
                                <p className="text-blue-400">
                                  <strong>Status: Confirmed</strong> — Your order has been approved! The outfits are packaged carefully and preparing for the courier dispatch.
                                </p>
                              )}
                              {order.status === 'Shipped' && (
                                <p className="text-purple-400">
                                  <strong>Status: Shipped</strong> — Your parcel is handed over to our delivery courier partner and is on the way to your door!
                                </p>
                              )}
                              {order.status === 'Delivered' && (
                                <p className="text-emerald-400">
                                  <strong>Status: Delivered</strong> — Package successfully received! Thank you for choosing Orvex for premium bespoke styling.
                                </p>
                              )}
                            </div>
                          </div>
                        ) : (
                          /* Cancelled State Cover Banner */
                          <div className="bg-red-500/5 p-4 rounded-xl border border-red-500/10 text-center space-y-1 max-w-md mx-auto">
                            <span className="inline-block bg-red-500 text-white text-[8px] font-black uppercase px-2 py-0.5 rounded">Cancelled</span>
                            <p className="text-[11px] text-red-450 leading-normal font-sans">
                              This order has been cancelled by Orvex support. This can be due to active mobile number unreachable, duplicate booking, order change or request.
                            </p>
                          </div>
                        )}

                        {/* Ordered Items List inside Tracer */}
                        <div className="bg-black/55 rounded-lg border border-gray-850/70 p-3 space-y-3 font-sans">
                          <span className="block text-[9px] text-gray-500 font-mono tracking-wider uppercase border-b border-gray-850 pb-1">Package Contents</span>
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex gap-2 justify-between items-center text-xs">
                              <div className="flex gap-2 items-center min-w-0">
                                <img src={item.image} alt={item.productName} className="w-8 h-10 object-cover rounded border border-gray-800 shrink-0 bg-gray-900" />
                                <div className="min-w-0">
                                  <h4 className="font-bold text-white uppercase truncate text-[11px]">{item.productName}</h4>
                                  <div className="flex gap-2 text-[8px] mt-0.5 font-mono text-gray-400">
                                    <span className="bg-gray-900 border border-gray-850 px-1 py-0.1 rounded shrink-0">Size: <strong className="text-gold uppercase">{item.size || 'Standard'}</strong></span>
                                    <span className="bg-gray-900 border border-gray-850 px-1 py-0.1 rounded shrink-0">Qty: <strong>{item.quantity}</strong></span>
                                  </div>
                                </div>
                              </div>
                              <span className="text-white font-mono text-[11px] shrink-0">Tk {item.price * item.quantity}</span>
                            </div>
                          ))}
                        </div>

                        {/* Customer Information Preview */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-[#131313] rounded-lg p-3 border border-gray-850/60 text-[10px] leading-normal font-sans">
                          <div className="space-y-0.5">
                            <span className="block text-[8px] text-gray-500 uppercase tracking-widest font-mono">Receiver Address</span>
                            <span className="text-white font-bold block">{order.customerName}</span>
                            <span className="text-gray-400 block line-clamp-2">{order.customerAddress}, {order.customerDistrict}, {order.customerDivision}</span>
                          </div>
                          
                          <div className="space-y-0.5 text-left sm:text-right">
                            <span className="block text-[8px] text-gray-500 uppercase tracking-widest font-mono text-left sm:text-right">Contact Details</span>
                            <span className="text-white font-bold block select-all font-mono">{order.customerPhone}</span>
                            {order.customerAltPhone && <span className="text-gray-400 block select-all font-mono">{order.customerAltPhone}</span>}
                          </div>
                        </div>

                        {/* Action buttons inside Order Tracer Card */}
                        <div className="flex gap-2.5 pt-1">
                          <a 
                            href={`https://wa.me/8801534001923?text=${encodeURIComponent(`Assalamu Alaikum. I want to inquire about my Order ${order.id}. Active Mobile: ${order.customerPhone}.`)}`}
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 text-[#25D366] px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center inline-flex gap-1 cursor-pointer flex-1 justify-center transition-all"
                          >
                            WhatsApp Inquiry
                          </a>
                          <a 
                            href="tel:01534001923" 
                            className="bg-gold/10 hover:bg-gold/20 border border-gold/30 text-gold px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center inline-flex gap-1 cursor-pointer flex-1 justify-center transition-all"
                          >
                            Call Support Hotline
                          </a>
                        </div>
                      </div>
                    );
                  });
                })()
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;

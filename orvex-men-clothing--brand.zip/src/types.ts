export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  discountText?: string;
  statusText?: string;
  viewCount?: number;
  category: 'Shirts' | 'T-Shirts' | 'Hoodies' | 'Formal Wear' | 'Accessories';
  description: string;
  images: string[];
  sizes?: string[];
  colors?: string[];
  features?: string[];
  material?: string;
  fit?: string;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  reviews?: Review[];
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize: string;
  selectedColor: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerAltPhone?: string;
  customerAddress: string;
  customerDistrict?: string;
  customerDivision?: string;
  deliveryNotes?: string;
  shippingCost?: number;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    price: number;
    size?: string;
    color?: string;
    image: string;
  }[];
  totalAmount: number;
  status: 'Pending' | 'Approved' | 'Shipped' | 'Delivered' | 'Cancelled';
  date: string;
}
